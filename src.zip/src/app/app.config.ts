export const AppConfig = {
    apiEndpoint: 'https://your-api-endpoint.com/api',
    authEndpoint: 'https://your-api-endpoint.com/auth',
    tokenExpirationTime: 3600, // in seconds
    refreshTokenExpirationTime: 86400, // in seconds
    windowsAuthEnabled: true,
};