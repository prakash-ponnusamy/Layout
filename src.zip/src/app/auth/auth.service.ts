import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { TokenManagerService } from './token-manager.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient, private tokenManager: TokenManagerService) {}

  login(username: string, password: string): Observable<boolean> {
    return this.http.post<{ token: string, refreshToken: string }>(`${this.apiUrl}/auth/login`, { username, password })
      .pipe(
        map(response => {
          this.tokenManager.setTokens(response.token, response.refreshToken);
          return true;
        }),
        catchError(() => of(false))
      );
  }

  logout(): void {
    this.tokenManager.clearTokens();
  }

  isLoggedIn(): boolean {
    return this.tokenManager.isTokenValid();
  }
}