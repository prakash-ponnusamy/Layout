import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TokenManagerService {
  private token: string | null = null;
  private refreshToken: string | null = null;

  setToken(token: string, refreshToken: string): void {
    this.token = token;
    this.refreshToken = refreshToken;
  }

  getToken(): string | null {
    return this.token;
  }

  getRefreshToken(): string | null {
    return this.refreshToken;
  }

  clearTokens(): void {
    this.token = null;
    this.refreshToken = null;
  }

  isLoggedIn(): boolean {
    return this.token !== null;
  }
}