import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class WindowsAuthService {
  private apiUrl = 'YOUR_API_URL'; // Replace with your API URL

  constructor(private http: HttpClient, private authService: AuthService) {}

  checkIfLoggedIn(): Observable<boolean> {
    return this.http.get<boolean>(`${this.apiUrl}/check-login`);
  }

  login(username: string, password: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, { username, password });
  }

  logout(): Observable<any> {
    return this.http.post(`${this.apiUrl}/logout`, {});
  }
}