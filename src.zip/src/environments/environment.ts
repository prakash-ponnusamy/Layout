export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000/api',
  authEndpoint: 'http://localhost:3000/api/auth',
  windowsAuthEnabled: true
};