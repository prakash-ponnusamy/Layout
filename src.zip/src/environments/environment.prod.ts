export const environment = {
  production: true,
  apiUrl: 'https://api.yourdomain.com',
  authEndpoint: '/auth/login',
  tokenRefreshEndpoint: '/auth/refresh',
  // Add any other production-specific settings here
};