import { Component, OnInit, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { EmployeeModel, EmployeeStatutoryModel } from '../../../../models/employee.model';
import { EmployeeService } from '../../../../services/employee.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-employee-statutory',
  templateUrl: './employee-statutory.component.html',
  styleUrls: ['./employee-statutory.component.scss'],
})

export class EmployeeStatutoryComponent implements OnInit {

  maxDate: Date;
  empStatutory: EmployeeStatutoryModel;
  selecteduanNumber: any;
  selectedpfNumber: any;
  selectedaadharNo: any;
  selectedbankAccount: any;
  selectedbankBranch: any;
  formSubmitted: boolean = false;
  response: any;
  employeeStatutoryID: number;

  aadharNo: string;
  panNumber: string;
  passportNo: string;
  bankBranch: string;
  bankAccount: string;
  ifscCode: string;
  uanNumber: string;
  pfNumber: string;
  esiNumber: string;
  pfJoiningDate: Date;
  pfLeavingDate: Date;

  @Input() userRoleName: string;
  @Input() regForm: FormGroup;
  @Input() employee: EmployeeModel;
  //@Output() refreshEmployeeInfo = new EventEmitter();

  constructor(private readonly employeeService: EmployeeService,
    private readonly toastr: ToastrService) {
    this.maxDate = new Date();
  }

  ngOnInit() {
    console.log('EmployeeStatutoryComponent');
    this.getEmployeeStatutory();

  }
  getEmployeeStatutory() {
    this.employeeService.getEmployeeStatutoryByEmployeeID(this.employee.employeeID).subscribe(
      res => {
        console.log(<any>res,'EmployeeStatutoryComponent result');
        this.empStatutory = <any>res;

        if (this.empStatutory !== null && this.empStatutory !== undefined) {
          this.employeeStatutoryID = this.empStatutory.employeeStatutoryID;
          this.aadharNo = this.empStatutory.aadharNo;
          this.panNumber = this.empStatutory.panNumber;
          this.passportNo = this.empStatutory.passportNo;
          this.bankBranch = this.empStatutory.bankBranch;
          this.bankAccount = this.empStatutory.bankAccount;
          this.ifscCode = this.empStatutory.ifscCode;
          this.uanNumber = this.empStatutory.uanNumber;
          this.pfNumber = this.empStatutory.pfNumber;
          this.pfJoiningDate = this.empStatutory.pfJoiningDate;
          this.pfLeavingDate = this.empStatutory.pfLeavingDate;
          this.esiNumber = this.empStatutory.esiNumber;


          this.bindEmployeeStatutory(this.empStatutory);
        }
      },
      error => {
        console.log(error);
      }
    );
  }

  bindEmployeeStatutory(employeeStatutory: EmployeeStatutoryModel) {
    console.log('EmployeeStatutoryComponent bind');
    console.log(employeeStatutory);
    this.regForm.get('employeeStatutory').patchValue({
      'aadharNo': employeeStatutory.aadharNo,
      'panNumber': employeeStatutory.panNumber,
      'passportNo': employeeStatutory.passportNo,
      'bankBranch': employeeStatutory.bankBranch,
      'bankAccount': employeeStatutory.bankAccount,
      'ifscCode': employeeStatutory.ifscCode,
      'uanNumber': employeeStatutory.uanNumber,
      'pfNumber': employeeStatutory.pfNumber,
      'pfJoiningDate': employeeStatutory.pfJoiningDate,
      'pfLeavingDate': employeeStatutory.pfLeavingDate,
      'esiNumber': employeeStatutory.esiNumber,
    });
    console.log(this.regForm.get('employeeStatutory').get('aadharNo').value);
    console.log('EmployeeStatutoryComponent end');
  }

  onEdit() {
    this.formSubmitted = true;
  }

  statutoryInfoSubmit() {
    console.log(this.regForm.get('employeeStatutory'));
    let employeeStatutory = {
      employeeId: this.employee.employeeID,
      employeeStatutoryID: this.employeeStatutoryID,
      aadharNo: this.regForm.get('employeeStatutory').get('aadharNo').value,
      panNumber: this.regForm.get('employeeStatutory').get('panNumber').value,
      passportNo: this.regForm.get('employeeStatutory').get('passportNo').value,
      bankBranch: this.regForm.get('employeeStatutory').get('bankBranch').value,
      bankAccount: this.regForm.get('employeeStatutory').get('bankAccount').value,
      ifscCode: this.regForm.get('employeeStatutory').get('ifscCode').value,
      uanNumber: this.regForm.get('employeeStatutory').get('uanNumber').value,
      pfNumber: this.regForm.get('employeeStatutory').get('pfNumber').value,
      pfJoiningDate: this.regForm.get('employeeStatutory').get('pfJoiningDate').value,
      pfLeavingDate: this.regForm.get('employeeStatutory').get('pfLeavingDate').value,
      esiNumber: this.regForm.get('employeeStatutory').get('esiNumber').value

      }
    console.log('employeeStatutory');
    console.log(employeeStatutory);

    if (this.employeeStatutoryID !== undefined && this.employeeStatutoryID !== null && this.employeeStatutoryID > 0) {
      this.updateEmployeeStatutory(employeeStatutory);
    }
    else {
      this.insertEmployeeStatutory(employeeStatutory);
    }
    this.formSubmitted = false;
  }

  insertEmployeeStatutory(employeeStatutory) {
    return this.employeeService.addEmployeeStatutory(employeeStatutory).subscribe(result => {
      this.response = result;

      if (this.response.succeeded === true) {
        this.toastr.success('Updated Successfully!');
        this.getEmployeeStatutory();
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }

  updateEmployeeStatutory(employeeStatutory) {
    return this.employeeService.updateEmployeeStatutoryAsync(employeeStatutory).subscribe(result => {
      this.response = result;

      if (this.response.succeeded === true) {
        this.toastr.success('Updated Successfully!');
        this.getEmployeeStatutory();
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }


  statutoryInfoCancel() {
    this.formSubmitted = false;
  }



}
