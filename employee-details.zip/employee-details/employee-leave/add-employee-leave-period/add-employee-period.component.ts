import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { FormBuilder, FormGroup } from "@angular/forms";
import { EmployeeService } from "../../../../../services/employee.service";
import { LeavePeriodService } from "../../../../../services/leave-period.service";
import { LeavePeriodModel } from "../../../../../models/leave-period.model";
import { ToastrService } from "ngx-toastr";
import { EmployeeModel } from "../../../../../models/employee.model";

@Component({
  selector: "add-employee-period",
  templateUrl: "./add-employee-period.component.html",
  styleUrls: ["./add-employee-period.component.scss"],
})
export class AddEmployeeLeavePeriodComponent implements OnInit {
  leavePeriodForm: FormGroup;
  leavePeriod: LeavePeriodModel;
  leavePeriodID: number;
  maxDate: Date;
  response: any;
  // leavePeriodList: LeavePeriodModel;

  constructor(
    private readonly formBuilder: FormBuilder,
    public employeeService: EmployeeService,
    private readonly leavePeriodService: LeavePeriodService,
    public dialogRef: MatDialogRef<AddEmployeeLeavePeriodComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: any,
    private toastr: ToastrService
  ) {
    this.leavePeriodForm = this.createFormGroup(data);
  }

  ngOnInit() {
    this.getPeriodByStatus();
    this.maxDate = new Date();
    console.log("leavePeriod ngOnInit");
    console.log(this.data);
  }

  getPeriodByStatus() {
    this.leavePeriodService.list().subscribe(
      (res) => {
        this.leavePeriod = <any>res;
        console.log(this.leavePeriod);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  createFormGroup(data: any) {
    return this.formBuilder.group({
      startDate: [""],
      endDate: [""],
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    console.log(this.leavePeriodForm);
    console.log("countcheck");
    if (this.leavePeriodForm.valid) {
      this.insertPeriod();
    } else {
      console.log("Please send valid data", this.leavePeriodForm.value);
    }
  }

  insertPeriod() {
    console.log(this.leavePeriodID, "this.leavePeriodForm");
    if (this.leavePeriodForm.valid) {
      this.dialogRef.close(this.leavePeriodForm.value);
    }
  }
}
