import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EmployeeService } from '../../../../../services/employee.service';
import { CompOffLeaveService } from '../../../../../services/com-off-leave.service';
import { CompOffLeaveModel } from '../../../../../models/com-off-leave.model';
import { ToastrService } from 'ngx-toastr';
import { LeaveMasterModel } from '../../../../../models/leave-details.model';
import { LeaveMasterService } from '../../../../../services/leave-master.service';

@Component({
  selector: 'add-employee-comp-off',
  templateUrl: './add-employee-comp-off.component.html',
  styleUrls: ['./add-employee-comp-off.component.scss']
})
export class AddEmployeeComOffComponent implements OnInit {
  LeaveMasterModel: LeaveMasterModel[];
  compOffForm: FormGroup;
  compOffLeave: CompOffLeaveModel;
  compOffLeaveID: number;
  maxDate: Date;
  response: any;
  compOffLeaveList: CompOffLeaveModel[];

  constructor(
    private readonly formBuilder: FormBuilder,
    public employeeService: EmployeeService,
    private readonly leaveMasterService: LeaveMasterService,
    private readonly compOffLeaveService: CompOffLeaveService,
    public dialogRef: MatDialogRef<AddEmployeeComOffComponent>, @Inject(MAT_DIALOG_DATA)
    public data: any, private toastr: ToastrService) {
    this.compOffForm = this.createFormGroup();
  }

  ngOnInit() {

    this.getLeaveTypesBasedOnLeaveMasterAvailabilty();
    this.getPenaltyByStatus();
    this.maxDate = new Date();
    console.log('compOffLeave ngOnInit');
    console.log(this.data);
  }

  getPenaltyByStatus() {
    this.compOffLeaveService.list().subscribe(
      res => {
        this.compOffLeave = <any>res;
        console.log(this.compOffLeave);
      },
      error => {
        console.log(error);
      }
    );
  }

  createFormGroup() {
    return this.formBuilder.group({
      workedDate: [''],
      noOfDays: [0],
      comments: [''],
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    console.log(this.compOffForm);
    if (this.compOffForm.valid) {

      // if (this.data.currentPenalty.length > 0)

      //if (this.data.currentPenalty[0].compOffLeaveID > 0)
      //   this.updatePenalty();
      // else
      if (Number(this.compOffForm.get('noOfDays').value) > 0) {
        this.insertComOff();
      }
      else {
        this.toastr.error('Please check no of days!');
      }
    }
    else {
      console.log('Please send valid data', this.compOffForm.value);
    }
  }

  insertComOff() {

    //console.log('this.compOffForm');
    //if (Number(this.compOffForm.get('leaveTypeID').value) != 1) //Loss Of Pay
    //{

    //  var leaveMaster = this.LeaveMasterModel.find(x => x.leaveTypeID == Number(this.compOffForm.get('leaveTypeID').value));
    //  console.log(leaveMaster, 'this.leaveMasterleaveMaster');

    //  if (leaveMaster.leaveBalance < Number(this.compOffForm.get('noOfDays').value)) {
    //    this.toastr.error("Employee does not have sufficient leaves balance. Please select valid leave type or verify the no of days on leave");
    //    return;
    //  }
    //}

    console.log('this.compOffForm');
    console.log(this.data.compOffLeaveID);

    let compOffLeave: any = {
      compOffLeaveID: 0,
      leavePeriodID: this.data.leavePeriodID,
      workedDate: this.compOffForm.get('workedDate').value,
      employeeID: this.data.employeeID,
      noOfDays: Number(this.compOffForm.get('noOfDays').value),
      comments: this.compOffForm.get('comments').value,
      appliedDate: new Date(),
      createdBy: this.data.loginEmployeeID
    };

    return this.compOffLeaveService.add(compOffLeave).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {
        this.toastr.success('Added Successfully!');
        this.dialogRef.close('success');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );

  }

  updateinsertComOff() {
    let compOffLeave: any = {
      compOffLeaveID: this.data.currentPenalty[0].compOffLeaveID,
      // endDate: this.compOffForm.get('startDate').value
    };
    console.log('this.compOffForm');
    return this.compOffLeaveService.update(compOffLeave).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {
        this.insertComOff();
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }


  getLeaveTypesBasedOnLeaveMasterAvailabilty() {
    this.leaveMasterService.getLeaveMasterDetailsByEmployeeID(this.data.employeeID, this.data.leavePeriodID).subscribe(
      res => {
        console.log(<any>res, ' getLeaveMasterDetailsByEmployeeID');

        this.LeaveMasterModel = (<any>res).filter(x => x.noOfLeaves > 0 || x.leaveTypeID == 1);

        this.LeaveMasterModel.forEach((item) => {
          //if (item.leaveTypeID != 1)
          //  item.leaveBalance = item.noOfLeaves - item.totalLeaveTaken;
          //else
          item.leaveBalance = Math.abs(item.noOfLeaves - item.totalLeaveTaken);
          item.usedLeaves = Math.abs((100 / item.noOfLeaves) * item.totalLeaveTaken);
        }
        );
        console.log(this.LeaveMasterModel, ' this.LeaveMasterModel');
        //this.LeaveMasterModel = res as LeaveMasterModel[];

      },
      error => {
        console.log(error);
      }
    )
  }



}
