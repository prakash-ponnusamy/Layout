import { Component, ViewChild, Input, OnInit } from "@angular/core";
import { FormBuilder, FormControl, FormGroup } from "@angular/forms";
import { MatTable, MatTableDataSource } from "@angular/material/table";
import { MatDialog } from "@angular/material/dialog";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { ToastrService } from "ngx-toastr";

import { AddEmployeeLeavePenaltyComponent } from "./add-employee-leave-penalty/add-employee-penalty.component";
import { EmployeeModel } from "../../../../models/employee.model";
import { LeaveMasterModel } from "../../../../models/leave-details.model";
import { EmployeeService } from "../../../../services/employee.service";
import { LeavePeriodModel } from "../../../../models/leave-period.model";
import { LeaveMasterService } from "../../../../services/leave-master.service";
import { LeaveDetailsService } from "../../../../services/leave-details.service";
import { JWTTokenService } from "../../../../services/jwttoken.service";
import { LeavePeriodService } from "../../../../services/leave-period.service";
import { AddEmployeeLeavePeriodComponent } from "./add-employee-leave-period/add-employee-period.component";
import { LeavePenaltyService } from "../../../../services/leave-penalty.service";
import { LeavePenaltyModel } from "../../../../models/leave-penalty.model";
import { CompOffLeaveService } from "../../../../services/com-off-leave.service";
import { CompOffLeaveModel } from "../../../../models/com-off-leave.model";
import { AddEmployeeComOffComponent } from "./add-employee-comp-off/add-employee-comp-off.component";
import { EditLeavePeriodDialogComponent } from "./edit-leave-period-dialog/edit-leave-period-dialog.component";

@Component({
  selector: "app-employee-leave",
  templateUrl: "./employee-leave.component.html",
  styleUrls: ["./employee-leave.component.scss"],
})
export class EmployeeLeaveComponent implements OnInit {
  ELEMENT_DATA: LeaveMasterModel[];
  leaveMasterModel: LeaveMasterModel[];
  leavePenaltyModel: LeavePenaltyModel[];
  compOffleaveModel: CompOffLeaveModel[];
  elements: any = [];
  displayedColumns: string[] = [
    "leaveTypeName",
    "noOfLeaves",
    "totalLeaveTaken",
    "leaveBalance",
  ];
  penaltyColumns: string[] = [
    "leaveTypeName",
    "noOfDays",
    "appliedDate",
    "createdEmployee",
    "comments",
  ];
  compOffColumns: string[] = [
    "workedDate",
    "noOfDays",
    "appliedDate",
    "createdEmployee",
    "comments",
  ];

  leavePeriodColumns = ["fiscalStartDate", "fiscalEndDate", "actions"];
  loginEmployeeID: number;
  selectedLeavePeriod: string;
  leavePeriodID: number;
  leavePeriodModel: LeavePeriodModel[];
  leaveDetailsForm: FormGroup;
  response: any;
  step = 0;
  @Input() regForm: FormGroup;
  dataSource = new MatTableDataSource();
  penaltyDataSource = new MatTableDataSource();
  compOffDataSource = new MatTableDataSource();
  leavePerioddataSource = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @ViewChild("penaltySort") penaltySort = new MatSort();
  @ViewChild("compOffSort") compOffSort = new MatSort();

  @ViewChild("penaltyPaginator") penaltyPaginator: MatPaginator;
  @ViewChild("compOffPaginator") compOffPaginator: MatPaginator;

  @Input() userRoleName: string;
  @Input() employee: EmployeeModel;

  constructor(
    private employeeService: EmployeeService,
    private leaveMasterService: LeaveMasterService,
    private readonly leavePeriodService: LeavePeriodService,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private readonly jwtTokenService: JWTTokenService,
    private readonly leavePenaltyService: LeavePenaltyService,
    private readonly compOffLeaveService: CompOffLeaveService,

    private readonly formBuilder: FormBuilder
  ) {
    this.leaveDetailsForm = this.createFormGroup();
  }

  ngOnInit() {
    this.loginEmployeeID = Number(this.jwtTokenService.getUserId());
    this.getLeavePeriodByEmployeeID();
  }

  createFormGroup() {
    return this.formBuilder.group({
      leavePeriodID: [0],
    });
  }

  getLeavePeriodByEmployeeID() {
    this.leavePeriodService
      .getLeavePeriodByEmployeeID(this.employee.employeeID)
      .subscribe((res) => {
        console.log(<any>res, "<any>res");
        this.leavePeriodModel = <any>res;
        this.leavePerioddataSource = new MatTableDataSource(
          this.leavePeriodModel
        );

        var todayDate = new Date();
        this.leavePeriodModel.forEach((item) => {
          // if (Date.parse(item.fiscalStartDate) > todayDate) {

          if (
            new Date(item.fiscalStartDate) <= todayDate &&
            new Date(item.fiscalEndDate) > todayDate
          ) {
            this.leaveDetailsForm.patchValue({
              leavePeriodID: item.leavePeriodID,
            });
            this.leavePeriodID = item.leavePeriodID;
            this.getLeaveTypesBasedOnLeaveMasterAvailabilty(this.leavePeriodID);
            this.getLeavePenaltyByEmployeeID(this.leavePeriodID);
            this.getComOffLeaveByEmployeeID(this.leavePeriodID);

            console.log(this.leavePeriodID, "this.leavePeriodID");
          }
        });
      });
  }
  onLeavePeriodSelection(selectedLeavePeriod: string) {
    console.log(selectedLeavePeriod, "gggg");
    this.getLeaveTypesBasedOnLeaveMasterAvailabilty(
      Number(selectedLeavePeriod)
    );
    this.getLeavePenaltyByEmployeeID(Number(selectedLeavePeriod));
    this.getComOffLeaveByEmployeeID(Number(selectedLeavePeriod));

    this.leavePeriodID = Number(selectedLeavePeriod);
  }

  getLeaveTypesBasedOnLeaveMasterAvailabilty(leavePeriodID: number) {
    console.log(leavePeriodID, " getLeaveMasterDetailsByEmployeeID");
    this.leaveMasterService
      .getLeaveMasterDetailsByEmployeeID(
        this.employee.employeeID,
        leavePeriodID
      )
      .subscribe(
        (res) => {
          console.log(<any>res, " getLeaveMasterDetailsByEmployeeID");

          this.ELEMENT_DATA = <any>res; //.filter(x => x.noOfLeaves > 0 || x.leaveTypeID == 1);

          this.ELEMENT_DATA.forEach((item) => {
            if (item.leaveTypeID != 1)
              item.leaveBalance = item.noOfLeaves - item.totalLeaveTaken;
            else
              item.leaveBalance = Math.abs(
                item.noOfLeaves - item.totalLeaveTaken
              );

            item.usedLeaves = Math.abs(
              (100 / item.noOfLeaves) * item.totalLeaveTaken
            );
          });
          console.log(this.ELEMENT_DATA, " this.ELEMENT_DATAthis.ELEMENT_DATA");

          this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
        },
        (error) => {
          console.log(error);
        }
      );
  }

  onSubmit(): void {
    this.leaveMasterModel = this.ELEMENT_DATA.filter(
      (x) => x.noOfLeaves >= 0 && x.leaveTypeName != "Loss Of Pay"
    );
    console.log(this.leaveMasterModel, " console.log(error);");
    this.leaveMasterModel.forEach((x) =>
      this.leaveMasterService.update(x).subscribe(
        (result) => {
          this.response = result;
          this.getLeaveTypesBasedOnLeaveMasterAvailabilty(this.leavePeriodID);
        },
        (error) => {
          console.log(error);
        }
      )
    );
    this.toastr.success("Updated Successfully!");
  }

  onNewLeavePenalty(): void {
    const dialogRef = this.dialog.open(AddEmployeeLeavePenaltyComponent, {
      width: "40%",
      data: {
        formTitle: "Add New Leave Penalty",
        buttonName: "Submit",
        employeeID: this.employee.employeeID,
        leavePeriodID: this.leavePeriodID,
        loginEmployeeID: this.loginEmployeeID,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result !== undefined) this.ngOnInit();
    });
  }

  onNewCompOff(): void {
    const dialogRef = this.dialog.open(AddEmployeeComOffComponent, {
      width: "40%",
      data: {
        formTitle: "Add Compensatory Leave",
        buttonName: "Submit",
        employeeID: this.employee.employeeID,
        leavePeriodID: this.leavePeriodID,
        loginEmployeeID: this.loginEmployeeID,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result !== undefined) this.ngOnInit();
    });
  }

  onCreateLeavePeriod(): void {
    this.setStep(1);
    const dialogRef = this.dialog.open(AddEmployeeLeavePeriodComponent, {
      width: "40%",
      data: {
        formTitle: "Add New Leave Period",
        buttonName: "Submit",
        employeeID: this.employee.employeeID,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result !== undefined) {
        this.insertPeriod(result);
      }
    });
  }

  setStep(index: number) {
    this.step = index;
  }

  insertPeriod(data: any) {
    // Check for overlapping leave periods
    const newStart = new Date(data.startDate);
    const newEnd = new Date(data.endDate);

    const isOverlap = this.leavePeriodModel?.some((period) => {
      const periodStart = new Date(period.fiscalStartDate);
      const periodEnd = new Date(period.fiscalEndDate);
      // Overlap if start is before existing end and end is after existing start
      return newStart <= periodEnd && newEnd >= periodStart;
    });

    if (isOverlap) {
      this.toastr.error(
        "A leave period with overlapping dates already exists."
      );
      return;
    }

    let leavePeriod: any = {
      leavePeriodID: 0,
      employeeID: this.employee.employeeID,
      fiscalStartDate: data.startDate,
      fiscalEndDate: data.endDate,
    };
    return this.leavePeriodService.add(leavePeriod).subscribe(
      (result) => {
        this.response = result;
        if (this.response.succeeded === true) {
          this.toastr.success("Added Successfully!");
          this.getLeavePeriodByEmployeeID();
          this.setStep(0);
        } else if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
      },
      (error) => {
        console.log(error);
      }
    );
  }

  getLeavePenaltyByEmployeeID(leavePeriodID: number) {
    this.leavePenaltyService
      .getLeavePenaltyByEmployeeIDLeavePeriodID(
        this.employee.employeeID,
        leavePeriodID
      )
      .subscribe(
        (res) => {
          this.leavePenaltyModel = <any>res;
          this.penaltyDataSource = new MatTableDataSource(
            this.leavePenaltyModel
          );
          this.penaltyDataSource.paginator = this.penaltyPaginator;
          this.penaltyDataSource.sort = this.penaltySort;
        },
        (error) => {
          console.log(error);
        }
      );
  }
  getComOffLeaveByEmployeeID(leavePeriodID: number) {
    this.compOffLeaveService
      .getCompOffLeaveByEmployeeIDLeavePeriodID(
        this.employee.employeeID,
        leavePeriodID
      )
      .subscribe(
        (res) => {
          this.compOffleaveModel = <any>res;
          console.log(this.compOffleaveModel);
          this.compOffDataSource = new MatTableDataSource(
            this.compOffleaveModel
          );
          this.compOffDataSource.paginator = this.compOffPaginator;
          this.compOffDataSource.sort = this.compOffSort;
        },
        (error) => {
          console.log(error);
        }
      );
  }
  isCurrentDateInRange(start: string | Date, end: string | Date): boolean {
    const today = new Date();
    const startDate = new Date(start);
    const endDate = new Date(end);
    return today >= startDate && today <= endDate;
  }

  openEditLeavePeriodDialog(element: LeavePeriodModel): void {
    const dialogRef = this.dialog.open(EditLeavePeriodDialogComponent, {
      width: "400px",
      data: { ...element },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        const newStart = new Date(result.fiscalStartDate);
        const newEnd = new Date(result.fiscalEndDate);

        // Check for overlapping leave periods, excluding the current one
        const isOverlap = this.leavePeriodModel?.some((period) => {
          if (period.leavePeriodID === element.leavePeriodID) return false;
          const periodStart = new Date(period.fiscalStartDate);
          const periodEnd = new Date(period.fiscalEndDate);
          return newStart <= periodEnd && newEnd >= periodStart;
        });

        if (isOverlap) {
          this.toastr.error(
            "A leave period with overlapping dates already exists."
          );
          return;
        }

        let leavePeriod: any = {
          leavePeriodID: element.leavePeriodID,
          fiscalStartDate: result.fiscalStartDate,
          fiscalEndDate: result.fiscalEndDate,
        };
        this.leavePeriodService.update(leavePeriod).subscribe(
          () => {
            this.getLeavePeriodByEmployeeID();
            this.toastr.success("Leave period updated successfully!");
          },
          (error) => {
            this.toastr.error("Failed to update leave period.");
          }
        );
      }
    });
  }
}
