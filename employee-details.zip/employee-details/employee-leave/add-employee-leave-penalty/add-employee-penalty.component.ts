import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EmployeeService } from '../../../../../services/employee.service';
import { LeavePenaltyService } from '../../../../../services/leave-penalty.service';
import { LeavePenaltyModel } from '../../../../../models/leave-penalty.model';
import { ToastrService } from 'ngx-toastr';
import { LeaveMasterModel } from '../../../../../models/leave-details.model';
import { LeaveMasterService } from '../../../../../services/leave-master.service';

@Component({
  selector: 'add-employee-penalty',
  templateUrl: './add-employee-penalty.component.html',
  styleUrls: ['./add-employee-penalty.component.scss']
})
export class AddEmployeeLeavePenaltyComponent implements OnInit {
  LeaveMasterModel: LeaveMasterModel[];
  leavePenaltyForm: FormGroup;
  leavePenalty: LeavePenaltyModel;
  leavePenaltyID: number;
  maxDate: Date;
  response: any;
  leavePenaltyList: LeavePenaltyModel[];

  constructor(
    private readonly formBuilder: FormBuilder,
    public employeeService: EmployeeService,
    private readonly leaveMasterService: LeaveMasterService,
    private readonly leavePenaltyService: LeavePenaltyService,
    public dialogRef: MatDialogRef<AddEmployeeLeavePenaltyComponent>, @Inject(MAT_DIALOG_DATA)
    public data: any, private toastr: ToastrService) {
    this.leavePenaltyForm = this.createFormGroup();
  }

  ngOnInit() {

    this.getLeaveTypesBasedOnLeaveMasterAvailabilty();
    this.getPenaltyByStatus();
    this.maxDate = new Date();
    console.log('leavePenalty ngOnInit');
    console.log(this.data);


  }

  getPenaltyByStatus() {
    this.leavePenaltyService.list().subscribe(
      res => {
        this.leavePenalty = <any>res;
        console.log(this.leavePenalty);
      },
      error => {
        console.log(error);
      }
    );
  }

  createFormGroup() {
    return this.formBuilder.group({
      leaveTypeID: [0],
      noOfDays: [0],
      comments: [''],
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    console.log(this.leavePenaltyForm);
    if (this.leavePenaltyForm.valid) {

      // if (this.data.currentPenalty.length > 0)

      //if (this.data.currentPenalty[0].leavePenaltyID > 0)
      //   this.updatePenalty();
      // else
      if (Number(this.leavePenaltyForm.get('noOfDays').value) > 0) {
        this.insertPenalty();
      }
      else {
        this.toastr.error('Please check no of days!');
      }
    }
    else {
      console.log('Please send valid data', this.leavePenaltyForm.value);
    }
  }

  insertPenalty() {

    console.log('this.leavePenaltyForm');
    if (Number(this.leavePenaltyForm.get('leaveTypeID').value) != 1) //Loss Of Pay
    {

      var leaveMaster = this.LeaveMasterModel.find(x => x.leaveTypeID == Number(this.leavePenaltyForm.get('leaveTypeID').value));
      console.log(leaveMaster, 'this.leaveMasterleaveMaster');

      if (leaveMaster.leaveBalance < Number(this.leavePenaltyForm.get('noOfDays').value)) {
        this.toastr.error("Employee does not have sufficient leaves balance. Please select valid leave type or verify the no of days on leave");
        return;
      }
    }

    console.log('this.leavePenaltyForm');
    console.log(this.data.leavePenaltyID);

    let leavePenalty: any = {
      leavePenaltyID: 0,
      leavePeriodID: this.data.leavePeriodID,
      employeeID: this.data.employeeID,
      leaveTypeID: Number(this.leavePenaltyForm.get('leaveTypeID').value),
      noOfDays: Number(this.leavePenaltyForm.get('noOfDays').value),
      comments: this.leavePenaltyForm.get('comments').value,
      appliedDate: new Date(),
      createdBy: this.data.loginEmployeeID
    };

    return this.leavePenaltyService.add(leavePenalty).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {
        this.toastr.success('Added Successfully!');
        this.dialogRef.close('success');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );

  }

  updatePenalty() {
    let leavePenalty: any = {
      leavePenaltyID: this.data.currentPenalty[0].leavePenaltyID,
      // endDate: this.leavePenaltyForm.get('startDate').value
    };
    console.log('this.leavePenaltyForm');
    return this.leavePenaltyService.update(leavePenalty).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {
        this.insertPenalty();
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }


  getLeaveTypesBasedOnLeaveMasterAvailabilty() {
    this.leaveMasterService.getLeaveMasterDetailsByEmployeeID(this.data.employeeID, this.data.leavePeriodID).subscribe(
      res => {
        console.log(<any>res, ' getLeaveMasterDetailsByEmployeeID');

        this.LeaveMasterModel = (<any>res).filter(x => x.noOfLeaves > 0 || x.leaveTypeID == 1);

        this.LeaveMasterModel.forEach((item) => {
          //if (item.leaveTypeID != 1)
          //  item.leaveBalance = item.noOfLeaves - item.totalLeaveTaken;
          //else
          item.leaveBalance = Math.abs(item.noOfLeaves - item.totalLeaveTaken);
          item.usedLeaves = Math.abs((100 / item.noOfLeaves) * item.totalLeaveTaken);
        }
        );
        console.log(this.LeaveMasterModel, ' this.LeaveMasterModel');
        //this.LeaveMasterModel = res as LeaveMasterModel[];

      },
      error => {
        console.log(error);
      }
    )
  }



}
