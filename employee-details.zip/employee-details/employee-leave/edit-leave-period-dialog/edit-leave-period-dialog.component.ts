import { Component, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { LeavePeriodService } from "../../../../../services/leave-period.service";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-edit-leave-period-dialog",
  templateUrl: "./edit-leave-period-dialog.component.html",
})
export class EditLeavePeriodDialogComponent {
  editForm: FormGroup;
  leavePeriodID: number;
  response: any;
  constructor(
    private readonly leavePeriodService: LeavePeriodService,
    private readonly toastr: ToastrService,
    public dialogRef: MatDialogRef<EditLeavePeriodDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder
  ) {
    this.editForm = this.fb.group({
      fiscalStartDate: [data.fiscalStartDate, Validators.required],
      fiscalEndDate: [data.fiscalEndDate, Validators.required],
    });
    this.leavePeriodID = data.leavePeriodID;
  }

  onSave() {
    console.log(this.leavePeriodID, "this.leavePeriodForm");
    if (this.editForm.valid) {
      this.dialogRef.close(this.editForm.value);
    }
  }
}
