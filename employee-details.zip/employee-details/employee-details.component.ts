import { Component, OnInit, ViewChild } from "@angular/core";
import { EmployeeModel } from "src/app/models/employee.model";
import { EmployeeService } from "src/app/services/employee.service";
import { MatDialog } from "@angular/material/dialog";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { ToastrService } from "ngx-toastr";
import { CompanyModel } from "../../../models/company.model";
import { CompanyService } from "../../../services/masters/company.service";
import { MatAccordion } from "@angular/material/expansion";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { MAT_DATE_FORMATS } from "@angular/material/core";
import { MY_DATE_FORMATS } from "../../common/global-constants";
import { ActivatedRoute } from "@angular/router";
import { JWTTokenService } from "../../../services/jwttoken.service";
import { AppAuthService } from "../../../services/auth.service";
import { UtilityService } from "../../../services/utility.service";
import { Location } from "@angular/common";

@Component({
  selector: "app-employee-details",
  templateUrl: "./employee-details.component.html",
  styleUrls: ["./employee-details.component.scss"],
  providers: [{ provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS }],
})
export class EmployeeDetailsComponent implements OnInit {
  employeeID: number;
  employee: EmployeeModel;
  personalForm: FormGroup;
  registrationForm: FormGroup;
  companyList: CompanyModel[];
  elements: any = [];
  selectedCompany: any;
  displayedColumns: string[] = [
    "image",
    "employeeCode",
    "companyName",
    "departmentName",
    "doj",
    "doc",
    "action",
  ];
  dataSource = new MatTableDataSource();
  userRoleName: string;
  response: any;
  file: string = "";

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatAccordion) accordion: MatAccordion;

  formSubmitted: boolean = false;

  constructor(
    private readonly jwtTokenService: JWTTokenService,
    private employeeService: EmployeeService,
    private readonly authService: AppAuthService,
    private readonly utilityService: UtilityService,
    private route: ActivatedRoute,
    private readonly toastr: ToastrService,
    private location: Location
  ) {
    console.log(this.route.snapshot.queryParams.employeeId);
    this.employeeID = this.route.snapshot.queryParams.employeeId;
    this.registrationForm = this.createFormGroup();
  }

  ngOnInit() {
    this.userRoleName = this.jwtTokenService.getUserRoleName();
    this.getEmployeeInformationByID();
  }

  createFormGroup() {
    return new FormGroup({
      personalDetails: new FormGroup({
        title: new FormControl(null),
        firstName: new FormControl(""),
        lastName: new FormControl(""),
        birthDate: new FormControl(""),
        gender: new FormControl(null),
        bloodGroup: new FormControl(""),
        guardianName: new FormControl(""),
        kmcNumber: new FormControl(""),
        nationality: new FormControl(null),
        maritalStatus: new FormControl(null),
        email: new FormControl("", [Validators.required, Validators.email]),
        mobile: new FormControl(""),
      }),
      contactDetails: new FormGroup({
        presentAddressLine1: new FormControl(""),
        presentAddressLine2: new FormControl(""),
        presentCountryID: new FormControl(null),
        presentStateID: new FormControl(null),
        presentCityID: new FormControl(null),
        presentPostalCode: new FormControl(""),
        permanentAddressLine1: new FormControl(""),
        permanentAddressLine2: new FormControl(""),
        permanentCountryID: new FormControl(null),
        permanentStateID: new FormControl(null),
        permanentCityID: new FormControl(null),
        permanentPostalCode: new FormControl(""),
      }),
      workDetails: new FormGroup({
        employeeCode: new FormControl(""),
        companyID: new FormControl(""),
        branchID: new FormControl(null),
        departmentID: new FormControl(null),
        subDepartmentID: new FormControl(null),
        employmentTypeID: new FormControl(""),
        doj: new FormControl(""),
        doc: new FormControl(""),
        employeeStatusID: new FormControl(""),
        roleID: new FormControl(null),
        reportingManagerID: new FormControl(null),
        isManager: new FormControl(null),
        skipManagerApproval: new FormControl(null),
        resignedDate: new FormControl(""),
        lastWorkingDate: new FormControl(""),
        resignationReason: new FormControl(""),
      }),
      employeeStatutory: new FormGroup({
        aadharNo: new FormControl(""),
        panNumber: new FormControl(""),
        passportNo: new FormControl(""),
        bankBranch: new FormControl(""),
        bankAccount: new FormControl(""),
        ifscCode: new FormControl(""),
        uanNumber: new FormControl(""),
        pfNumber: new FormControl(""),
        pfJoiningDate: new FormControl(""),
        pfLeavingDate: new FormControl(""),
        esiNumber: new FormControl(""),
      }),
    });
  }

  refreshEmployeeInfo(msg, child) {
    console.log(msg);
    console.log("refreshEmployeeInfo");
    console.log(child);
    this.getEmployeeInformationByID();
  }

  getEmployeeInformationByID() {
    this.employeeService.get(this.employeeID).subscribe(
      (result) => {
        console.log(<any>result, "empinfo");
        this.employee = <any>result;
        //this.employee.photo = 'assets/images/employee/' + this.employee.photo;
        this.file = "assets/images/employee/" + this.employee.photo;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  resetPassword() {
    let auth = {
      id: this.employee.authID,
      password: this.employee.employeeCode,
    };
    console.log(auth);
    var confirmCheck = confirm(
      "Are you sure you want to reset the selected staff password?"
    );
    if (confirmCheck) this.resetPasswordByAuthID(auth);
  }

  resetPasswordByAuthID(auth) {
    return this.authService.resetPasswordByAuthID(auth).subscribe(
      (result) => {
        this.response = result;
        console.log(this.response, " this.response this.response");
        if (this.response.succeeded === true) {
          this.toastr.success("Password resetted Successfully!");
        } else if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
      },
      (error) => {
        console.log(error);
      }
    );
  }

  onFileChange(event: any) {
    const files = event.target.files as FileList;

    if (files.length > 0) {
      const _file = URL.createObjectURL(files[0]);
      this.file = _file;
      console.log(files[0]);

      this.uploadPhoto(files[0]);
      this.resetInput();
    }
  }

  resetInput() {
    const input = document.getElementById(
      "avatar-input-file"
    ) as HTMLInputElement;
    if (input) {
      input.value = "";
    }
  }

  updatePhoto(fileName: string) {
    this.employee.photo = fileName;
    console.log(fileName, "fileNamefileName");
    return this.employeeService
      .updatePersonalInformation(this.employee)
      .subscribe(
        (result) => {
          this.response = result;

          if (this.response.succeeded === true) {
          } else if (this.response.failed === true) {
            this.toastr.error(this.response.message);
          }
        },
        (error) => {
          console.log(error);
        }
      );
  }

  uploadPhoto(fileSource): void {
    if (fileSource != "") {
      const current = new Date();
      const formData = new FormData();
      var extn = fileSource.name.substr(fileSource.name.lastIndexOf(".") + 1);
      console.log(extn, "fileName");

      var fileNameFinal = this.employee.employeeCode + "." + extn;

      formData.append("attachmentFile", fileSource, fileNameFinal);
      console.log(fileNameFinal, "fileName");
      console.log(formData);

      this.updatePhoto(fileNameFinal);

      this.utilityService
        .uploadFiles(formData, "Photos")
        .subscribe((result) => {
          this.response = result;
        });
    }
  }

  goBack() {
    this.location.back();
  }
}
