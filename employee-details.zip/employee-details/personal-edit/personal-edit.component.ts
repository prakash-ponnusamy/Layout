import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { EmployeeModel } from '../../../../models/employee.model';
import { EmployeeService } from '../../../../services/employee.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-personal-edit',
  templateUrl: './personal-edit.component.html',
  styleUrls: ['./personal-edit.component.scss'],
})

export class PersonalEditComponent implements OnInit {

  maxDate: Date;
  selectedNationality: any;
  selectedMaritalStatus: any;
  selectedTitle: any;
  selectedBloodGroup: any;
  selectedGender: any;
  formSubmitted: boolean = false;
  response: any;

  @Input() userRoleName: string;
  @Input() regForm: FormGroup;
  @Input() employee: EmployeeModel;
  @Output() refreshEmployeeInfo = new EventEmitter();

  constructor(private readonly employeeService: EmployeeService,
    private readonly toastr: ToastrService) {
    this.maxDate = new Date();
  }

  ngOnInit() {
    console.log(this.employee,'pwertjwerhlweh');
    this.bindPersonalInformation(this.employee);
  }

  bindPersonalInformation(employee: EmployeeModel) {
    this.regForm.get('personalDetails').patchValue({
      title: employee.title,
      firstName: employee.firstName,
      lastName: employee.lastName,
      birthDate: employee.birthDate,
      gender: employee.gender,
      bloodGroup: employee.bloodGroup,
      guardianName: employee.guardianName,
      kmcNumber: employee.kmcNumber,
      nationality: employee.nationality,
      maritalStatus: employee.maritalStatus,
      email: employee.email,
      mobile: employee.mobile
    });
  }

  onEdit() {
    this.formSubmitted = true;
  }

  basicInfoSubmit() {
    console.log(this.regForm.get('personalDetails'));
    let personalInfo = {
      employeeId: this.employee.employeeID,
      title: Number(this.regForm.get('personalDetails').get('title').value),
      firstName: this.regForm.get('personalDetails').get('firstName').value,
      lastName: this.regForm.get('personalDetails').get('lastName').value,
      birthDate: this.regForm.get('personalDetails').get('birthDate').value,
      gender: this.regForm.get('personalDetails').get('gender').value,
      bloodGroup: Number(this.regForm.get('personalDetails').get('bloodGroup').value),
      guardianName: this.regForm.get('personalDetails').get('guardianName').value,
      kmcNumber: this.regForm.get('personalDetails').get('kmcNumber').value,
      nationality: Number(this.regForm.get('personalDetails').get('nationality').value),
      maritalStatus: Number(this.regForm.get('personalDetails').get('maritalStatus').value),
      email: this.regForm.get('personalDetails').get('email').value,
      mobile: this.regForm.get('personalDetails').get('mobile').value,
    }
    console.log('personalInfo');
    console.log(personalInfo);
    this.insertEmployee(personalInfo);

    this.formSubmitted = false;
  }

  insertEmployee(personalInfo) {
    console.log(personalInfo);
    console.log('employee1');

    return this.employeeService.updatePersonalInformation(personalInfo).subscribe(result => {
      this.response = result;

      if (this.response.succeeded === true) {
        this.toastr.success('Updated Successfully!');
        this.refreshEmployeeInfo.emit('call parent');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );

  }

  basicInfoCancel() {
    this.formSubmitted = false;
  }

  step1Submitted() {
    console.log('sdfsdf');
    ////this.regForm.get('personalDetails').get('firstName').markAsTouched();
    ////this.regForm.get('personalDetails').get('firstName').updateValueAndValidity();
    //this.regForm.get('personalDetails').get('lastName').markAsTouched();
    //this.regForm.get('personalDetails').get('lastName').updateValueAndValidity();
    //console.log('dddd');
  }

}
