import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from '../../../../../services/employee.service';
import { EmployeeQualificationModel } from '../../../../../models/employee.model';
import { QualificationService } from '../../../../../services/masters/qualification.service';
import { QualificationModel } from '../../../../../models/qualification.model';
import * as moment from 'moment';
import { UtilityService } from '../../../../../services/utility.service';

@Component({
  selector: 'add-employee-qualification',
  templateUrl: './add-employee-qualification.component.html',
  styleUrls: ['./add-employee-qualification.component.scss']
})
export class AddEmployeeQualificationComponent implements OnInit {
  employeeQualificationForm: FormGroup;
  employeeQualification: EmployeeQualificationModel;
  employeeQualificationID: number;
  maxDate: Date;
  response: any;
  qualificationList: QualificationModel;
  selectedEmployeeID: number;
  employeeDetail: string;

  constructor(
    private readonly formBuilder: FormBuilder,
    public employeeService: EmployeeService,
    private readonly qualificationService: QualificationService,
    private readonly utilityService: UtilityService,
    public dialogRef: MatDialogRef<AddEmployeeQualificationComponent>, @Inject(MAT_DIALOG_DATA)
    public data: any, private toastr: ToastrService) {
    this.employeeQualificationForm = this.createFormGroup(data);
  }

  ngOnInit() {
    this.getQualificationByStatus();
    this.maxDate = new Date();
    this.employeeQualificationID = this.data.employeeQualificationID;
    this.selectedEmployeeID = this.data.selectedEmployeeID;
    this.employeeDetail = this.data.employeeDetail;


    console.log(this.data);

    if (this.employeeQualificationID !== undefined && this.employeeQualificationID !== null && this.employeeQualificationID > 0) {
      this.setQualificationForm(this.employeeQualificationID);
    }
  }

  getQualificationByStatus() {
    this.qualificationService.getQualificationByStatus().subscribe(
      res => {
        this.qualificationList = <any>res;
        console.log(this.qualificationList);
      },
      error => {
        console.log(error);
      }
    );
  }

  setQualificationForm(employeeQualificationID: number) {
    this.employeeService.getEmployeeQualification(employeeQualificationID).subscribe(
      result => {
        this.employeeQualificationForm = this.createFormGroup(result);
        this.employeeQualification = result;
      },
      error => {
        console.log(error);
      });
  }

  createFormGroup(data: any) {
    return this.formBuilder.group({
      employeeQualificationID: [data ? data.employeeQualificationID : 0],
      qualificationID: [data ? data.qualificationID : 0],
      major: [data ? data.major : '', [Validators.required]],
      institute: [data ? data.institute : ''],
      completionDate: [data ? data.completionDate : ''],
      notes: [data ? data.notes : ''],
      document: [data ? data.document : ''],
      fileSource: new FormControl('')
    });
  }

  get f() {
    return this.employeeQualificationForm.controls;
  }

  onFileChange(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      console.log(file);
      this.employeeQualificationForm.patchValue({
        fileSource: file
      });
      console.log(this.employeeQualificationForm.get('fileSource').value.name);
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    console.log(this.employeeQualificationForm);
    var fileSource = this.employeeQualificationForm.get('fileSource').value;
    var fileNameFinal = null;
    var fileName = this.employeeQualificationForm.get('document').value;
    if (fileSource != '') {
      const current = new Date();
      const timestamp = current.getTime();
      const formData = new FormData();
      var extn = fileSource.name.substr(fileSource.name.lastIndexOf('.') + 1);
      console.log(extn, 'fileName')

      fileNameFinal = this.employeeDetail + '' + this.employeeQualificationForm.get('qualificationID').value +
        this.employeeQualificationForm.get('major').value + '.' + extn;

      formData.append('attachmentFile', this.employeeQualificationForm.get('fileSource').value, fileNameFinal);
      console.log(fileNameFinal, 'fileName')
      console.log(this.employeeQualificationForm.get('document').value);
      console.log(formData);
      this.uploadDocuments(formData);
    }

    if (this.employeeQualificationForm.valid) {

      let employeeQualification = {
        employeeQualificationID: (this.employeeQualificationForm.get('employeeQualificationID').value === null) ? 0 : Number(this.employeeQualificationForm.get('employeeQualificationID').value),
        employeeID: this.selectedEmployeeID,
        qualificationID: Number(this.employeeQualificationForm.get('qualificationID').value),
        major: this.employeeQualificationForm.get('major').value,
        institute: this.employeeQualificationForm.get('institute').value,
        completionDate: this.employeeQualificationForm.get('completionDate').value,
        notes: this.employeeQualificationForm.get('notes').value,
        document: fileNameFinal == null ? fileName : fileNameFinal
      };
      console.log(employeeQualification);
      console.log('employeeQualification');
      if (employeeQualification.employeeQualificationID !== null && employeeQualification.employeeQualificationID > 0 && employeeQualification.employeeQualificationID !== undefined)
        this.updateQualification(employeeQualification);
      else
        this.insertQualification(employeeQualification);
    }
    else {
      console.log('Please send valid data', this.employeeQualificationForm.value);
    }
  }

  insertQualification(employeeQualification) {
    console.log('this.employeeQualificationForm');
    return this.employeeService.addEmployeeQualification(employeeQualification).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {
        this.toastr.success('Added Successfully!');
        this.dialogRef.close('success');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }

  updateQualification(employeeQualification) {
    return this.employeeService.updateEmployeeQualificationAsync(employeeQualification).subscribe(
      result => {

        this.response = result;

        if (this.response.succeeded === true) {
          this.toastr.success('Updated Successfully!');
          this.dialogRef.close('success');
        }
        else
          if (this.response.failed === true) {
            this.toastr.error(this.response.message);
          }
      },
      error => {
        console.log(error);
      }
    );
  }

  uploadDocuments(formData): void {
    this.utilityService.uploadDocuments(formData).subscribe(result => {
      this.response = result;

    });
  }
}
