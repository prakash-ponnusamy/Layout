import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { EmployeeQualificationModel, EmployeeModel } from '../../../../models/employee.model';
import { EmployeeService } from '../../../../services/employee.service';
import { AddEmployeeQualificationComponent } from './add-employee-qualification/add-employee-qualification.component';

@Component({
  selector: 'app-employee-qualifications',
  templateUrl: './employee-qualifications.component.html',
  styleUrls: ['./employee-qualifications.component.scss']
})
export class EmployeeQualificationsComponent implements OnInit {
  ELEMENT_DATA: EmployeeQualificationModel[];
  elements: any = [];
  displayedColumns: string[] = ['qualificationCode', 'major', 'institute', 'completionDate', 'document', 'action'];
  @Input() regForm: FormGroup;
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @Input() userRoleName: string;
  @Input() employee: EmployeeModel;

  constructor(private employeeService: EmployeeService,
    private toastr: ToastrService,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.getEmployeeQualificationByEmployeeID();
  }

  getEmployeeQualificationByEmployeeID() {
    this.employeeService.getEmployeeQualificationByEmployeeID(this.employee.employeeID).subscribe(
      res => {
        console.log('getEmployeeQualificationByEmployeeID');
        
        this.ELEMENT_DATA = <any>res;

        this.ELEMENT_DATA.forEach((item) => {
          item.document = item.document !== null ? "assets/documents/" + item.document : null;
        }); 
        this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error => {
        console.log(error);
      }
    )
  }

  onCreate(): void {
    const dialogRef = this.dialog.open(AddEmployeeQualificationComponent, {
      width: '70%',
      data: { formTitle: 'Add New Qualification', buttonName: 'Submit', selectedEmployeeID: this.employee.employeeID, employeeDetail: this.employee.employeeCode + this.employee.fullName }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  onEdit(employeeQualificationID: number) {
    const dialogRef = this.dialog.open(AddEmployeeQualificationComponent, {
      width: '70%',
      data: { formTitle: 'Update Qualification', buttonName: 'Update', employeeQualificationID: employeeQualificationID, selectedEmployeeID: this.employee.employeeID, employeeDetail: this.employee.employeeCode + this.employee.fullName }
    });

    dialogRef.afterClosed().subscribe(result => {
      ;
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  onDelete(employeeQualificationID: number) {
    let result = confirm('Are you want to remove this?');
    if (result) {
      this.employeeService.deleteEmployeeQualification(employeeQualificationID).subscribe(
        res => {
          this.toastr.warning('Deleted Successfully');
          this.ngOnInit();
        },
        error => {
          console.log(error);
        });
    }
  }
}
