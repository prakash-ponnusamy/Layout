import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from '../../../../../services/employee.service';
import { WorkExperienceModel } from '../../../../../models/employee.model';
import * as moment from 'moment';
import { UtilityService } from '../../../../../services/utility.service';

@Component({
  selector: 'add-work-experience',
  templateUrl: './add-work-experience.component.html',
  styleUrls: ['./add-work-experience.component.scss']
})
export class AddWorkExperienceComponent implements OnInit {
  workExperienceForm: FormGroup;
  workExperience: WorkExperienceModel;
  experienceID: number;
  maxDate: Date;
  response: any;
  selectedEmployeeID: number;
  employeeDetail: string;

  constructor(
    private readonly formBuilder: FormBuilder,
    public employeeService: EmployeeService,
    private readonly utilityService: UtilityService,
    public dialogRef: MatDialogRef<AddWorkExperienceComponent>, @Inject(MAT_DIALOG_DATA)
    public data: any, private toastr: ToastrService) {
    this.workExperienceForm = this.createFormGroup(data);
  }

  ngOnInit() {
    this.maxDate = new Date();
    this.experienceID = this.data.experienceID;
    this.selectedEmployeeID = this.data.selectedEmployeeID;
    this.employeeDetail = this.data.employeeDetail;
    console.log(this.data);
    console.log(this.experienceID);

    if (this.experienceID !== undefined && this.experienceID !== null && this.experienceID > 0) {
      this.setQualificationForm(this.experienceID);
    }
  }

  setQualificationForm(experienceID: number) {
    console.log('setQualificationForm');
    this.employeeService.getWorkExperience(experienceID).subscribe(
      result => {
        this.workExperienceForm = this.createFormGroup(result);
      },
      error => {
        console.log(error);
      });
  }

  createFormGroup(data: any) {
    return this.formBuilder.group({
      experienceID: [data ? data.experienceID : 0],
      companyName: [data ? data.companyName : ''],
      jobTitle: [data ? data.jobTitle : ''],
      jobDescription: [data ? data.jobDescription : ''],
      fromDate: [data ? data.fromDate : ''],
      toDate: [data ? data.toDate : ''],
      document: [data ? data.document : ''],
      fileSource: new FormControl('')
    });
  }

  get f() {
    return this.workExperienceForm.controls;
  }

  onFileChange(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      console.log(file);
      this.workExperienceForm.patchValue({
        fileSource: file
      });
      console.log(this.workExperienceForm.get('fileSource').value.name);
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    console.log(this.workExperienceForm);

    var fileSource = this.workExperienceForm.get('fileSource').value;

    if (fileSource != '') {
      const current = new Date();
      const formData = new FormData();
      var extn = fileSource.name.substr(fileSource.name.lastIndexOf('.') + 1);
      console.log(extn, 'fileName')

      var fileNameFinal = this.employeeDetail + '' + this.workExperienceForm.get('experienceID').value +
        this.workExperienceForm.get('jobTitle').value + '.' + extn;

      formData.append('attachmentFile', this.workExperienceForm.get('fileSource').value, fileNameFinal);
      console.log(fileNameFinal, 'fileName')
      console.log(this.workExperienceForm.get('document').value);
      console.log(formData);
      this.uploadDocuments(formData);
    }

    if (this.workExperienceForm.valid) {

      let workExperience = {
        experienceID: (this.workExperienceForm.get('experienceID').value === null) ? 0 : Number(this.workExperienceForm.get('experienceID').value),
        employeeID: this.selectedEmployeeID,
        companyName: this.workExperienceForm.get('companyName').value,
        jobTitle: this.workExperienceForm.get('jobTitle').value,
        jobDescription: this.workExperienceForm.get('jobDescription').value,
        fromDate: this.workExperienceForm.get('fromDate').value,
        toDate: this.workExperienceForm.get('toDate').value,
        document: fileNameFinal == null ? this.workExperience.document : fileNameFinal
      };
      console.log(workExperience);
      console.log('workExperience');
      if (workExperience.experienceID !== null && workExperience.experienceID > 0 && workExperience.experienceID !== undefined)
        this.updateQualification(workExperience);
      else
        this.insertQualification(workExperience);
    }
    else {
      console.log('Please send valid data', this.workExperienceForm.value);
    }
  }

  insertQualification(workExperience) {
    console.log('this.workExperienceForm');
    return this.employeeService.addWorkExperience(workExperience).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {
        this.toastr.success('Added Successfully!');
        this.dialogRef.close('success');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }

  updateQualification(workExperience) {
    return this.employeeService.updateWorkExperienceAsync(workExperience).subscribe(
      result => {
        
        this.response = result;

        if (this.response.succeeded === true) {
          this.toastr.success('Updated Successfully!');
          this.dialogRef.close('success');
        }
        else
          if (this.response.failed === true) {
            this.toastr.error(this.response.message);
          }
      },
      error => {
        console.log(error);
      }
    );
  }

  uploadDocuments(formData): void {
    this.utilityService.uploadDocuments(formData).subscribe(result => {
      this.response = result;
      
    });
  }
}
