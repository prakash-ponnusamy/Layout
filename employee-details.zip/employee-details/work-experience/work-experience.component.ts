import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { WorkExperienceModel, EmployeeModel } from '../../../../models/employee.model';
import { EmployeeService } from '../../../../services/employee.service';
import { AddWorkExperienceComponent } from './add-work-experience/add-work-experience.component';

@Component({
  selector: 'app-work-experience',
  templateUrl: './work-experience.component.html',
  styleUrls: ['./work-experience.component.scss']
})
export class WorkExperienceComponent implements OnInit {
  ELEMENT_DATA: WorkExperienceModel[];
  elements: any = [];
  displayedColumns: string[] = ['companyName', 'jobTitle', 'jobDescription', 'fromDate', 'toDate', 'document', 'action'];

  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @Input() regForm: FormGroup;
  @Input() userRoleName: string;
  @Input() employee: EmployeeModel;

  constructor(private employeeService: EmployeeService,
    private toastr: ToastrService,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.getWorkExperienceByEmployeeID();
  }

  getWorkExperienceByEmployeeID() {
    this.employeeService.getWorkExperienceByEmployeeID(this.employee.employeeID).subscribe(
      res => {
        console.log('getWorkExperienceByEmployeeID');
        
        this.ELEMENT_DATA = <any>res;
        this.ELEMENT_DATA.forEach((item) => {
          item.document = item.document !== null ? "assets/documents/" + item.document : null;
        }); 
        this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error => {
        console.log(error);
      }
    )
  }

  onCreate(): void {
    const dialogRef = this.dialog.open(AddWorkExperienceComponent, {
      width: '60%',
      data: { formTitle: 'Add Work Experience', buttonName: 'Submit', selectedEmployeeID: this.employee.employeeID, employeeDetail: this.employee.employeeCode + this.employee.fullName  }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  onEdit(experienceID: number) {
    const dialogRef = this.dialog.open(AddWorkExperienceComponent, {
      width: '60%',
      data: { formTitle: 'Update Work Experience', buttonName: 'Update', experienceID: experienceID, selectedEmployeeID: this.employee.employeeID, employeeDetail: this.employee.employeeCode + this.employee.fullName }
    });

    dialogRef.afterClosed().subscribe(result => {
      ;
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  onDelete(workExperienceID: number) {
    let result = confirm('Are you want to remove this?');
    if (result) {
      this.employeeService.deleteWorkExperience(workExperienceID).subscribe(
        res => {
          this.toastr.warning('Deleted Successfully');
          this.ngOnInit();
        },
        error => {
          console.log(error);
        });
    }
  }
}
