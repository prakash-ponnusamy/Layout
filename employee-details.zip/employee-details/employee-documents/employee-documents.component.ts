import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { DocumentCategoriesModel } from '../../../../models/document-categories.model';
import { EmployeeDocumentsModel, EmployeeModel } from '../../../../models/employee.model';
import { EmployeeService } from '../../../../services/employee.service';
import { DocumentCategoriesService } from '../../../../services/masters/document-categories.service';
import { AddEmployeeDocumentsComponent } from './add-employee-documents/add-employee-documents.component';

@Component({
  selector: 'app-employee-documents',
  templateUrl: './employee-documents.component.html',
  styleUrls: ['./employee-documents.component.scss']
})
export class EmployeeDocumentsComponent implements OnInit {
  ELEMENT_DATA: EmployeeDocumentsModel[];
  elements: any = [];
  displayedColumns: string[] = ['documentCategoryName', 'documentTypeName', 'notes', 'document', 'action'];
  @Input() regForm: FormGroup;
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  documentCategoriesList: DocumentCategoriesModel[];
  selectedDocumentCategory: string;
  @Input() userRoleName: string;
  @Input() employee: EmployeeModel;

  constructor(private employeeService: EmployeeService,
    private readonly documentCategoriesService: DocumentCategoriesService,
    private toastr: ToastrService,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.getDocumentCategories();
    this.getEmployeeDocumentsByEmployeeID(0);
  }

  getEmployeeDocumentsByEmployeeID(documentCategoryID: number) {
    this.employeeService.getEmployeeDocumentsByEmployeeID(this.employee.employeeID).subscribe(
      res => {
        console.log('getEmployeeDocumentsByEmployeeID');
        
        this.ELEMENT_DATA = <any>res;
        if (documentCategoryID > 0)
          this.ELEMENT_DATA = this.ELEMENT_DATA.filter(x => x.documentCategoryID == documentCategoryID);

        this.ELEMENT_DATA.forEach((item) => {
          item.document = item.document !== null ? "assets/documents/" + item.document : null;
        });
        this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error => {
        console.log(error);
      }
    )
  }

  getDocumentCategories() {
    this.documentCategoriesService.list().subscribe(
      res => {
        this.documentCategoriesList = <any>res;
        this.documentCategoriesList = this.documentCategoriesList.filter(x => x.isActive == true);
        console.log(this.documentCategoriesList);
      },
      error => {
        console.log(error);
      }
    );
  }

  onDocumentCategorySelection(selectedDocumentCategory: string) {
    console.log(selectedDocumentCategory);
    this.getEmployeeDocumentsByEmployeeID(Number(selectedDocumentCategory));
  }

  onCreate(): void {
    const dialogRef = this.dialog.open(AddEmployeeDocumentsComponent, {
      width: '70%',
      data: { formTitle: 'Add New Documents', buttonName: 'Submit', selectedEmployeeID: this.employee.employeeID, employeeDetail: this.employee.employeeCode + this.employee.fullName }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  onEdit(employeeDocumentID: number) {
    const dialogRef = this.dialog.open(AddEmployeeDocumentsComponent, {
      width: '70%',
      data: { formTitle: 'Update Documents', buttonName: 'Update', employeeDocumentID: employeeDocumentID, selectedEmployeeID: this.employee.employeeID, employeeDetail: this.employee.employeeCode + this.employee.fullName }
    });

    dialogRef.afterClosed().subscribe(result => {
      ;
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  onDelete(employeeDocumentID: number) {
    let result = confirm('Are you want to remove this?');
    if (result) {
      this.employeeService.deleteEmployeeDocuments(employeeDocumentID).subscribe(
        res => {
          this.toastr.warning('Deleted Successfully');
          this.ngOnInit();
        },
        error => {
          console.log(error);
        });
    }
  }
}
