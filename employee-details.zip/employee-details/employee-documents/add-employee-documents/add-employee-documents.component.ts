import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from '../../../../../services/employee.service';
import { EmployeeDocumentsModel } from '../../../../../models/employee.model';
import { DocumentTypesService } from '../../../../../services/masters/document-types.service';
import { DocumentCategoriesService } from '../../../../../services/masters/document-categories.service';
import { DocumentTypesModel } from '../../../../../models/document-types.model';
import { DocumentCategoriesModel } from '../../../../../models/document-categories.model';
import * as moment from 'moment';
import { UtilityService } from '../../../../../services/utility.service';

@Component({
  selector: 'add-employee-documents',
  templateUrl: './add-employee-documents.component.html',
  styleUrls: ['./add-employee-documents.component.scss']
})
export class AddEmployeeDocumentsComponent implements OnInit {
  employeeDocumentsForm: FormGroup;
  employeeDocuments: EmployeeDocumentsModel;
  employeeDocumentID: number;
  maxDate: Date;
  response: any;
  documentTypesList: DocumentTypesModel[];
  documentCategoriesList: DocumentCategoriesModel[];
  selectedEmployeeID: number;
  employeeDetail: string;
  selectedDocumentCategory: string;

  constructor(
    private readonly formBuilder: FormBuilder,
    public employeeService: EmployeeService,
    private readonly documentTypesService: DocumentTypesService,
    private readonly documentCategoriesService: DocumentCategoriesService,
    private readonly utilityService: UtilityService,
    public dialogRef: MatDialogRef<AddEmployeeDocumentsComponent>, @Inject(MAT_DIALOG_DATA)
    public data: any, private toastr: ToastrService) {
    this.employeeDocumentsForm = this.createFormGroup(data);
  }

  ngOnInit() {
    this.getDocumentCategories();
    this.maxDate = new Date();
    this.employeeDocumentID = this.data.employeeDocumentID;
    this.selectedEmployeeID = this.data.selectedEmployeeID;
    this.employeeDetail = this.data.employeeDetail;


    console.log(this.data);

    if (this.employeeDocumentID !== undefined && this.employeeDocumentID !== null && this.employeeDocumentID > 0) {
      this.setEmployeeDocumentsForm(this.employeeDocumentID);
    }
  }

  onDocumentCategorySelection(selectedDocumentCategory: string) {
    console.log(selectedDocumentCategory);
    this.getAllDocumentTypes(Number(selectedDocumentCategory));
  }


  getAllDocumentTypes(selectedDocumentCategory: number) {
    if (selectedDocumentCategory > 0) {
      this.documentTypesService.getDocumentTypesModelByDocumentCategoryID(selectedDocumentCategory).subscribe(
        res => {
          this.documentTypesList = <any>res;
          this.documentTypesList = this.documentTypesList.filter(x => x.isActive == true);
          console.log(this.documentTypesList);
        },
        error => {
          console.log(error);
        }
      );
    }
  }

  getDocumentCategories() {
    this.documentCategoriesService.list().subscribe(
      res => {
        this.documentCategoriesList = <any>res;
        this.documentCategoriesList = this.documentCategoriesList.filter(x => x.isActive == true);
        console.log(this.documentCategoriesList);
      },
      error => {
        console.log(error);
      }
    );
  }

  setEmployeeDocumentsForm(employeeDocumentID: number) {
    this.employeeService.getEmployeeDocumentsByEmployeeDocumentID(employeeDocumentID).subscribe(
      result => {
        console.log(result, 'res');
        this.getAllDocumentTypes(result[0].documentCategoryID);
        this.employeeDocumentsForm = this.createFormGroup(result[0]);
      },
      error => {
        console.log(error);
      });
  }

  createFormGroup(data: any) {
    return this.formBuilder.group({
      employeeDocumentID: [data ? data.employeeDocumentID : 0],
      employeeID: [data ? data.employeeID : 0],
      documentCategoryID: [data ? data.documentCategoryID : '', [Validators.required]],
      documentTypeID: [data ? data.documentTypeID : '', [Validators.required]],
      notes: [data ? data.notes : ''],
      document: [data ? data.document : ''],
      fileSource: new FormControl('')
    });
  }

  get f() {
    return this.employeeDocumentsForm.controls;
  }

  onFileChange(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      console.log(file);
      this.employeeDocumentsForm.patchValue({
        fileSource: file
      });
      console.log(this.employeeDocumentsForm.get('fileSource').value.name);
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    console.log(this.employeeDocumentsForm);
    var fileSource = this.employeeDocumentsForm.get('fileSource').value;

    var fileNameFinal = this.employeeDocumentsForm.get('document').value;

    if (fileSource != '') {
      const current = new Date();
      const timestamp = current.getTime();
      const formData = new FormData();
      var extn = fileSource.name.substr(fileSource.name.lastIndexOf('.') + 1);
      console.log(extn, 'fileName')

      fileNameFinal = this.employeeDetail + '' + timestamp + '.' + extn;

      formData.append('attachmentFile', this.employeeDocumentsForm.get('fileSource').value, fileNameFinal);
      console.log(fileNameFinal, 'fileName')
      console.log(this.employeeDocumentsForm.get('document').value);
      console.log(formData);
      this.uploadDocuments(formData);
    }

    if (this.employeeDocumentsForm.valid) {

      let employeeDocuments = {
        employeeDocumentID: (this.employeeDocumentsForm.get('employeeDocumentID').value === null) ? 0 : Number(this.employeeDocumentsForm.get('employeeDocumentID').value),
        employeeID: this.selectedEmployeeID,
        documentCategoryID: Number(this.employeeDocumentsForm.get('documentCategoryID').value),
        documentTypeID: Number(this.employeeDocumentsForm.get('documentTypeID').value),
        notes: this.employeeDocumentsForm.get('notes').value,
        document: fileNameFinal
      };
      console.log(employeeDocuments);
      console.log('employeeDocuments');
      if (employeeDocuments.employeeDocumentID !== null && employeeDocuments.employeeDocumentID > 0 && employeeDocuments.employeeDocumentID !== undefined)
        this.updateEmployeeDocuments(employeeDocuments);
      else
        this.insertEmployeeDocuments(employeeDocuments);
    }
    else {
      console.log('Please send valid data', this.employeeDocumentsForm.value);
    }
  }

  insertEmployeeDocuments(employeeDocuments) {
    console.log('this.employeeDocumentsForm');
    return this.employeeService.addEmployeeDocuments(employeeDocuments).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {
        this.toastr.success('Added Successfully!');
        this.dialogRef.close('success');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }

  updateEmployeeDocuments(employeeDocuments) {
    return this.employeeService.updateEmployeeDocumentsAsync(employeeDocuments).subscribe(
      result => {

        this.response = result;

        if (this.response.succeeded === true) {
          this.toastr.success('Updated Successfully!');
          this.dialogRef.close('success');
        }
        else
          if (this.response.failed === true) {
            this.toastr.error(this.response.message);
          }
      },
      error => {
        console.log(error);
      }
    );
  }

  uploadDocuments(formData): void {
    this.utilityService.uploadDocuments(formData).subscribe(result => {
      this.response = result;

    });
  }
}
