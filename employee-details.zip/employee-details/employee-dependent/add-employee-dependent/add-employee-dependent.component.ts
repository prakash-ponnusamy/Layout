import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from '../../../../../services/employee.service';
import * as moment from 'moment';
import { EmployeeDependentModel } from '../../../../../models/employee.model';

@Component({
  selector: 'add-employee-dependent',
  templateUrl: './add-employee-dependent.component.html',
  styleUrls: ['./add-employee-dependent.component.scss']
})
export class AddEmployeeDependentComponent implements OnInit {
  employeeDependentForm: FormGroup;
  employeeDependent: EmployeeDependentModel;
  employeeDependentID: number;
  selectedEmployeeID: number;
  maxDate: Date;
  response: any;

  constructor(
    private readonly formBuilder: FormBuilder,
    public employeeService: EmployeeService,
    public dialogRef: MatDialogRef<AddEmployeeDependentComponent>, @Inject(MAT_DIALOG_DATA)
    public data: any, private toastr: ToastrService) {
    this.employeeDependentForm = this.createFormGroup(data);
  }

  ngOnInit() {
    
    this.maxDate = new Date();
    this.employeeDependentID = this.data.employeeDependentID;
    this.selectedEmployeeID = this.data.selectedEmployeeID;
    console.log(this.data);

    if (this.employeeDependentID !== undefined && this.employeeDependentID !== null && this.employeeDependentID > 0) {
      this.setDependentForm(this.employeeDependentID);
    }
  }

  setDependentForm(employeeDependentID: number) {
    this.employeeService.getEmployeeDependent(employeeDependentID).subscribe(
      result => {
        this.employeeDependentForm = this.createFormGroup(result);
      },
      error => {
        console.log(error);
      });
  }

  createFormGroup(data: any) {
    return this.formBuilder.group({
      employeeDependentID: [data ? data.employeeDependentID : 0],
      dependentName: [data ? data.dependentName : ''],
      relationship: [data ? data.relationship : ''],
      birthDate: [data ? data.birthDate : ''],
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    console.log(this.employeeDependentForm);

    if (this.employeeDependentForm.valid) {

      let employeeDependent = {
        employeeDependentID: (this.employeeDependentForm.get('employeeDependentID').value === null) ? 0 : Number(this.employeeDependentForm.get('employeeDependentID').value),
        employeeID: Number(this.selectedEmployeeID),
        dependentName: this.employeeDependentForm.get('dependentName').value,
        relationship: Number(this.employeeDependentForm.get('relationship').value),
        birthDate: this.employeeDependentForm.get('birthDate').value,
      };
      console.log(employeeDependent);
      console.log('employeeDependent');
      if (employeeDependent.employeeDependentID !== null && employeeDependent.employeeDependentID > 0 && employeeDependent.employeeDependentID !== undefined)
        this.updateDependent(employeeDependent);
      else
        this.insertDependent(employeeDependent);
    }
    else {
      console.log('Please send valid data', this.employeeDependentForm.value);
    }
  }

  insertDependent(employeeDependent) {
    console.log('this.employeeDependentForm');
    return this.employeeService.addEmployeeDependent(employeeDependent).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {
        this.toastr.success('Added Successfully!');
        this.dialogRef.close('success');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }

  updateDependent(employeeDependent) {
    return this.employeeService.updateEmployeeDependentAsync(employeeDependent).subscribe(
      result => {
        
        this.response = result;

        if (this.response.succeeded === true) {
          this.toastr.success('Updated Successfully!');
          this.dialogRef.close('success');
        }
        else
          if (this.response.failed === true) {
            this.toastr.error(this.response.message);
          }
      },
      error => {
        console.log(error);
      }
    );
  }
}
