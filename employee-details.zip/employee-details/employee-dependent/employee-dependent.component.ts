import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { EmployeeDependentModel, EmployeeModel } from '../../../../models/employee.model';
import { EmployeeService } from '../../../../services/employee.service';
import { AddEmployeeDependentComponent } from './add-employee-dependent/add-employee-dependent.component';

@Component({
  selector: 'app-employee-dependent',
  templateUrl: './employee-dependent.component.html',
  styleUrls: ['./employee-dependent.component.scss']
})
export class EmployeeDependentComponent implements OnInit {
  ELEMENT_DATA: EmployeeDependentModel[];
  elements: any = [];
  displayedColumns: string[] = ['dependentName', 'relationshipName', 'birthDate', 'action'];
  @Input() regForm: FormGroup;
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @Input() userRoleName: string;
  @Input() employee: EmployeeModel;

  constructor(private employeeService: EmployeeService,
    private toastr: ToastrService,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    console.log(this.employee.employeeID);
    this.getEmployeeDependentByEmployeeID();
  }

  getEmployeeDependentByEmployeeID() {
    this.employeeService.getEmployeeDependentByEmployeeID(this.employee.employeeID).subscribe(
      res => {
        console.log('getEmployeeDependentByEmployeeID');
        
        this.ELEMENT_DATA = <any>res;
        this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error => {
        console.log(error);
      }
    )
  }

  onCreate(): void {
    const dialogRef = this.dialog.open(AddEmployeeDependentComponent, {
      width: '40%',
      data: { formTitle: 'Add New Dependent', buttonName: 'Submit', selectedEmployeeID: this.employee.employeeID }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  onEdit(employeeDependentID: number) {
    const dialogRef = this.dialog.open(AddEmployeeDependentComponent, {
      width: '40%',
      data: { formTitle: 'Update Dependent', buttonName: 'Update', employeeDependentID: employeeDependentID, selectedEmployeeID: this.employee.employeeID}
    });

    dialogRef.afterClosed().subscribe(result => {
      ;
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  onDelete(employeeDependentID: number) {
    let result = confirm('Are you want to remove this?');
    if (result) {
      this.employeeService.deleteEmployeeDependent(employeeDependentID).subscribe(
        res => {
          this.toastr.warning('Deleted Successfully');
          this.ngOnInit();
        },
        error => {
          console.log(error);
        });
    }
  }
}
