import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from '../../../../../services/employee.service';
import { EmployeeCertificationModel } from '../../../../../models/employee.model';
import { UtilityService } from '../../../../../services/utility.service';


@Component({
  selector: 'add-employee-certification',
  templateUrl: './add-employee-certification.component.html',
  styleUrls: ['./add-employee-certification.component.scss']
})
export class AddEmployeeCertificationComponent implements OnInit {
  employeeCertificationForm: FormGroup;
  employeeCertification: EmployeeCertificationModel;
  employeeCertificationID: number;
  maxDate: Date;
  response: any;
  selectedEmployeeID: number;
  employeeDetail: string;

  constructor(
    private readonly formBuilder: FormBuilder,
    public employeeService: EmployeeService,
    private readonly utilityService: UtilityService,
    public dialogRef: MatDialogRef<AddEmployeeCertificationComponent>, @Inject(MAT_DIALOG_DATA)
    public data: any, private toastr: ToastrService) {
    this.employeeCertificationForm = this.createFormGroup(data);
  }

  ngOnInit() {
    this.maxDate = new Date();
    this.employeeCertificationID = this.data.employeeCertificationID;
    this.selectedEmployeeID = this.data.selectedEmployeeID;
    this.employeeDetail = this.data.employeeDetail;

    if (this.employeeCertificationID !== undefined && this.employeeCertificationID !== null && this.employeeCertificationID > 0) {
      this.setCertificationForm(this.employeeCertificationID);
    }
  }

  setCertificationForm(employeeCertificationID: number) {
    this.employeeService.getEmployeeCertification(employeeCertificationID).subscribe(
      result => {
        
        this.employeeCertificationForm = this.createFormGroup(result);
      },
      error => {
        console.log(error);
      });
  }

  createFormGroup(data: any) {
    return this.formBuilder.group({
      employeeCertificationID: [data ? data.employeeCertificationID : 0],
      certification: [data ? data.certification : '', [Validators.required]],
      institute: [data ? data.institute : ''],
      grantedON: [data ? data.grantedON : ''],
      validUntil: [data ? data.validUntil : ''],
      document: [data ? data.document : ''],
      fileSource: new FormControl('')
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  get f() {
    return this.employeeCertificationForm.controls;
  }

  onFileChange(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      console.log(file);
      this.employeeCertificationForm.patchValue({
        fileSource: file
      });
      console.log(this.employeeCertificationForm.get('fileSource').value.name);
    }
  }

  onSubmit(): void {
    console.log(this.employeeCertificationForm);
    var fileSource = this.employeeCertificationForm.get('fileSource').value;
    var fileNameFinal = null;
    var fileName = this.employeeCertificationForm.get('document').value;
    if (fileSource != '') {
      const current = new Date();
      const timestamp = current.getTime();
      const formData = new FormData();
      var extn = fileSource.name.substr(fileSource.name.lastIndexOf('.') + 1);
      console.log(extn, 'fileName')

      fileNameFinal = this.employeeDetail + '' + this.employeeCertificationForm.get('employeeCertificationID').value +
        this.employeeCertificationForm.get('certification').value + '.' + extn;

      formData.append('attachmentFile', this.employeeCertificationForm.get('fileSource').value, fileNameFinal);
      console.log(fileNameFinal, 'fileName')
      console.log(this.employeeCertificationForm.get('document').value);
     
      this.uploadDocuments(formData);
    }


    if (this.employeeCertificationForm.valid) {

      let employeeCertification = {
        employeeCertificationID: (this.employeeCertificationForm.get('employeeCertificationID').value === null) ? 0 : Number(this.employeeCertificationForm.get('employeeCertificationID').value),
        employeeID: this.selectedEmployeeID,
        certification: this.employeeCertificationForm.get('certification').value,
        institute: this.employeeCertificationForm.get('institute').value,
        grantedON: this.employeeCertificationForm.get('grantedON').value,
        validUntil: null,
        document: fileNameFinal == null ? fileName : fileNameFinal
      };
      console.log(employeeCertification);
      console.log('employeeCertification');
      if (employeeCertification.employeeCertificationID !== null && employeeCertification.employeeCertificationID > 0 && employeeCertification.employeeCertificationID !== undefined)
        this.updateCertification(employeeCertification);
      else
        this.insertCertification(employeeCertification);
    }
    else {
      console.log('Please send valid data', this.employeeCertificationForm.value);
    }
  }

  insertCertification(employeeCertification) {
    console.log('this.employeeCertificationForm');
    return this.employeeService.addEmployeeCertification(employeeCertification).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {
        this.toastr.success('Added Successfully!');
        this.dialogRef.close('success');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }

  updateCertification(employeeCertification) {
    return this.employeeService.updateEmployeeCertificationAsync(employeeCertification).subscribe(
      result => {
        
        this.response = result;

        if (this.response.succeeded === true) {
          this.toastr.success('Updated Successfully!');
          this.dialogRef.close('success');
        }
        else
          if (this.response.failed === true) {
            this.toastr.error(this.response.message);
          }
      },
      error => {
        console.log(error);
      }
    );
  }

  uploadDocuments(formData): void {
    this.utilityService.uploadDocuments(formData).subscribe(result => {
      this.response = result;
      
    });
  }
}
