import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { EmployeeCertificationModel, EmployeeModel } from '../../../../models/employee.model';
import { EmployeeService } from '../../../../services/employee.service';
import { AddEmployeeCertificationComponent } from './add-employee-certification/add-employee-certification.component';

@Component({
  selector: 'app-employee-certification',
  templateUrl: './employee-certification.component.html',
  styleUrls: ['./employee-certification.component.scss']
})
export class EmployeeCertificationsComponent implements OnInit {
  ELEMENT_DATA: EmployeeCertificationModel[];
  elements: any = [];
  displayedColumns: string[] = ['certification', 'institute', 'grantedON', 'validUntil','document', 'action'];
  @Input() regForm: FormGroup;
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @Input() userRoleName: string;
  @Input() employee: EmployeeModel;

  constructor(private employeeService: EmployeeService,
    private toastr: ToastrService,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.getEmployeeCertificationByEmployeeID();
  }

  getEmployeeCertificationByEmployeeID() {
    this.employeeService.getEmployeeCertificationByEmployeeID(this.employee.employeeID).subscribe(
      res => {
        console.log('getEmployeeCertificationByEmployeeID');
        this.ELEMENT_DATA = <any>res;
        this.ELEMENT_DATA.forEach((item) => {
          item.document = item.document !== null ? "assets/documents/" + item.document : null;
        }); 
        this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error => {
        console.log(error);
      }
    )
  }

  onCreate(): void {
    const dialogRef = this.dialog.open(AddEmployeeCertificationComponent, {
      width: '40%',
      data: { formTitle: 'Add New Certification', buttonName: 'Submit', selectedEmployeeID: this.employee.employeeID, employeeDetail: this.employee.employeeCode + this.employee.fullName }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  onEdit(employeeCertificationID: number) {
    const dialogRef = this.dialog.open(AddEmployeeCertificationComponent, {
      width: '40%',
      data: { formTitle: 'Update Certification', buttonName: 'Update', employeeCertificationID: employeeCertificationID, selectedEmployeeID: this.employee.employeeID, employeeDetail: this.employee.employeeCode + this.employee.fullName }
    });

    dialogRef.afterClosed().subscribe(result => {
      ;
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  onDelete(employeeCertificationID: number) {
    let result = confirm('Are you want to remove this?');
    if (result) {
      this.employeeService.deleteEmployeeCertification(employeeCertificationID).subscribe(
        res => {
          this.toastr.warning('Deleted Successfully');
          this.ngOnInit();
        },
        error => {
          console.log(error);
        });
    }
  }
}
