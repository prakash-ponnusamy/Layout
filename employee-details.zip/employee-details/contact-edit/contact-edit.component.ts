import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { StateService } from '../../../../services/masters/state.service';
import { ToastrService } from 'ngx-toastr';
import { CountryService } from '../../../../services/masters/country.service';
import { CountryModel } from '../../../../models/country.model';
import { CityService } from '../../../../services/masters/city.service';
import { EmployeeModel, AddressModel } from '../../../../models/employee.model';
import { EmployeeService } from '../../../../services/employee.service';


@Component({
  selector: 'app-contact-edit',
  templateUrl: './contact-edit.component.html',
  styleUrls: ['./contact-edit.component.scss']
})
export class ContactEditComponent implements OnInit {
  countryList: CountryModel[];
  selectedCountry: any;
  stateList: any;
  cityList: any;
  presentCountryList: CountryModel[];
  presentStateList: any;
  presentCityList: any;
  address: AddressModel[];
  formSubmitted: boolean = false;
  response: any;
  selectedState: string;
  selectedCity: string;
  selectedPresentCountry: string;
  selectedPresentState: string;
  selectedPresentCity: string;
  permanentAddress: AddressModel[];
  presentAddress: AddressModel[];

  @Input() userRoleName: string;
  @Input() regForm: FormGroup;
  @Input() employee: EmployeeModel;
  //@Output() refreshEmployeeInfo = new EventEmitter();

  constructor(
    private readonly countryService: CountryService,
    private readonly stateService: StateService,
    private readonly cityService: CityService,
    private toastr: ToastrService,
    private employeeService: EmployeeService
  ) {
    console.log('temp issue');
  }

  ngOnInit() {

    this.regForm.get('contactDetails').patchValue({
      //email: this.employee.email,
      //mobile: this.employee.mobile,
      permanentAddressLine1: '',
      permanentAddressLine2: '',
      permanentCountryID: null,
      permanentStateID: null,
      permanentCityID: null,
      permanentPostalCode: '',
      presentAddressLine1: '',
      presentAddressLine2: '',
      presentCountryID: null,
      presentStateID: null,
      presentCityID: null,
      presentPostalCode: ''
    });
    this.getCountries();
    console.log('ContactEditComponent');
    this.getAddressByEmployeeID();
    console.log(this.regForm);
  }

  bindContactInformation() {
    console.log(this.employee.mobile);
    console.log('this.address');

    this.permanentAddress = this.address.filter(x => x.addressTypeID === 1);
    this.presentAddress = this.address.filter(x => x.addressTypeID === 2);

    this.regForm.get('contactDetails').patchValue({
      //email: this.employee.email,
      //mobile: this.employee.mobile,
      permanentAddressLine1: this.permanentAddress[0].addressLine1,
      permanentAddressLine2: this.permanentAddress[0].addressLine2,
      permanentCountryID: this.permanentAddress[0].countryID,
      permanentStateID: this.permanentAddress[0].stateID,
      permanentCityID: this.permanentAddress[0].cityID,
      permanentPostalCode: this.permanentAddress[0].postalCode,
      presentAddressLine1: this.presentAddress[0].addressLine1,
      presentAddressLine2: this.presentAddress[0].addressLine2,
      presentCountryID: this.presentAddress[0].countryID,
      presentStateID: this.presentAddress[0].stateID,
      presentCityID: this.presentAddress[0].cityID,
      presentPostalCode: this.presentAddress[0].postalCode
    });

    this.getStates(this.permanentAddress[0].countryID);
    this.getPresentStates(this.presentAddress[0].countryID);
    this.regForm.get('contactDetails').patchValue({
      permanentStateID: this.permanentAddress[0].stateID,
      presentStateID: this.presentAddress[0].stateID,
    });

    this.getCities(this.permanentAddress[0].stateID);
    this.getPresentCities(this.presentAddress[0].stateID);
    this.regForm.get('contactDetails').patchValue({
      permanentCityID: this.permanentAddress[0].cityID,
      presentCityID: this.presentAddress[0].cityID,
    });
  }

  onCountrySelection(selectedCountry: string) {
    console.log(selectedCountry);
    this.stateList = null;
    this.cityList = null;
    this.getStates(Number(selectedCountry));
  }

  onStateSelection(selectedState: string) {
    console.log(selectedState);
    this.cityList = null;
    this.getCities(Number(selectedState));
  }

  onPresentCountrySelection(selectedPresentCountry: string) {
    this.presentStateList = null;
    this.presentCityList = null;
    this.getPresentStates(Number(selectedPresentCountry));

  }

  onPresentStateSelection(selectedPresentState: string) {
    this.presentCityList = null;
    this.getPresentCities(Number(selectedPresentState));
  }

  getCountries() {
    this.countryService.list().subscribe(
      res => {
        this.countryList = <any>res;
        this.presentCountryList = <any>res;

      },
      error => {
        console.log(error);
      }
    );
  }

  getStates(selectedCountry: number) {
    console.log(selectedCountry);
    if (selectedCountry > 0) {
      this.stateService.getActiveStateList(selectedCountry).subscribe(
        res => {
          this.stateList = <any>res;
          
        },
        error => {
          console.log(error);
        }
      );
    }
  }
  getPresentStates(selectedPresentCountry: number) {
    console.log(selectedPresentCountry);
    if (selectedPresentCountry > 0) {
      this.stateService.getActiveStateList(selectedPresentCountry).subscribe(
        res => {
          this.presentStateList = <any>res;
          
        },
        error => {
          console.log(error);
        }
      );
    }
  }

  getCities(selectedState: number) {
    console.log(selectedState);
    if (selectedState > 0) {
      this.cityService.getActiveCityList(selectedState).subscribe(
        res => {
          this.cityList = <any>res;
          
        },
        error => {
          console.log(error);
        }
      );
    }
  }

  getPresentCities(selectedPresentState: number) {
    console.log(selectedPresentState);
    if (selectedPresentState > 0) {
      this.cityService.getActiveCityList(selectedPresentState).subscribe(
        res => {
          this.presentCityList = <any>res;
          
        },
        error => {
          console.log(error);
        }
      );
    }
  }

  copyPermanentToPresent(isChecked: boolean) {

    if (isChecked) {
      console.log(isChecked);
      this.presentStateList = null;
      this.presentCityList = null;
      this.getPresentStates(Number(this.regForm.get('contactDetails').value.permanentCountryID));
      this.getPresentCities(Number(this.regForm.get('contactDetails').value.permanentStateID));
      this.regForm.get('contactDetails').patchValue({
        presentAddressLine1: this.regForm.get('contactDetails').value.permanentAddressLine1,
        presentAddressLine2: this.regForm.get('contactDetails').value.permanentAddressLine2,
        presentCountryID: this.regForm.get('contactDetails').value.permanentCountryID,
        presentStateID: this.regForm.get('contactDetails').value.permanentStateID,
        presentCityID: this.regForm.get('contactDetails').value.permanentCityID,
        presentPostalCode: this.regForm.get('contactDetails').value.permanentPostalCode
      });
    }
    else {
      this.regForm.get('contactDetails').patchValue({
        presentAddressLine1: '',
        presentAddressLine2: '',
        presentCountryID: '',
        presentStateID: '',
        presentCityID: '',
        presentPostalCode: ''
      });
    }
  }

  getAddressByEmployeeID() {
    console.log('getAddressByEmployeeIDAsync');
    this.employeeService.getAddressByEmployeeID(this.employee.employeeID).subscribe(
      result => {
        console.log(<any>result);
        this.address = <any>result;
        console.log(this.address.length);
        if (this.address.length > 0)
          this.bindContactInformation();
      },
      error => {
        console.log(error);
        this.toastr.success('Internal Error!');
      }
    )
  }

  onEdit() {
    this.formSubmitted = true;
  }

  contactInfoCancel() {
    this.formSubmitted = false;
  }


  contactInfoSubmit() {
    console.log(this.regForm.get('contactDetails'));
    console.log(this.address);
    let contactInfo = [{
      AddressID: 0,
      EmployeeID: this.employee.employeeID,
      AddressTypeID: 1,
      AddressLine1: this.regForm.get('contactDetails').get('permanentAddressLine1').value,
      AddressLine2: this.regForm.get('contactDetails').get('permanentAddressLine2').value,
      CountryID: Number(this.regForm.get('contactDetails').get('permanentCountryID').value),
      StateID: Number(this.regForm.get('contactDetails').get('permanentStateID').value),
      CityID: Number(this.regForm.get('contactDetails').get('permanentCityID').value),
      PostalCode: this.regForm.get('contactDetails').get('permanentPostalCode').value,
    }, {
      AddressID: 0,
      EmployeeID: this.employee.employeeID,
      AddressTypeID: 2,
      AddressLine1: this.regForm.get('contactDetails').get('presentAddressLine1').value,
      AddressLine2: this.regForm.get('contactDetails').get('presentAddressLine2').value,
      CountryID: Number(this.regForm.get('contactDetails').get('presentCountryID').value),
      StateID: Number(this.regForm.get('contactDetails').get('presentStateID').value),
      CityID: Number(this.regForm.get('contactDetails').get('presentCityID').value),
      PostalCode: this.regForm.get('contactDetails').get('presentPostalCode').value,
      }];

    if (this.address.length == 0) {
      this.insertAddressInformation(contactInfo[0]);
      this.insertAddressInformation(contactInfo[1]);
    }
    else {
      contactInfo[0].AddressID = this.permanentAddress[0].addressID;
      contactInfo[1].AddressID = this.presentAddress[0].addressID;
      this.updateAddressInformation(contactInfo);
    }
    this.formSubmitted = false;
  }

  insertAddressInformation(contactInfo) {
    console.log(contactInfo);
    console.log('employee1');

    return this.employeeService.insertAddressInformation(contactInfo).subscribe(result => {
      this.response = result;

      if (this.response.succeeded === true) {
        this.toastr.success('Updated Successfully!');
        this.getAddressByEmployeeID();
        // this.refreshEmployeeInfo.emit('call parent');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }

  updateAddressInformation(contactInfo) {
    console.log(contactInfo);
    console.log('employee1');

    return this.employeeService.updateAddressInformation(contactInfo).subscribe(result => {
      this.response = result;

      if (this.response.succeeded === true) {
        this.toastr.success('Updated Successfully!');
        this.getAddressByEmployeeID();
        // this.refreshEmployeeInfo.emit('call parent');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }
}
