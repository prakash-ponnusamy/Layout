import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from '../../../../../services/employee.service';
import * as moment from 'moment';
import { EmployeeSkillsModel } from '../../../../../models/employee.model';
import { UtilityService } from '../../../../../services/utility.service';

@Component({
  selector: 'add-employee-skills',
  templateUrl: './add-employee-skills.component.html',
  styleUrls: ['./add-employee-skills.component.scss']
})
export class AddEmployeeSkillsComponent implements OnInit {
  employeeSkillsForm: FormGroup;
  employeeSkills: EmployeeSkillsModel;
  employeeSkillID: number;
  maxDate: Date;
  response: any;
  selectedEmployeeID: number;
  employeeDetail: string;

  constructor(
    private readonly formBuilder: FormBuilder,
    public employeeService: EmployeeService,
    private readonly utilityService: UtilityService,
    public dialogRef: MatDialogRef<AddEmployeeSkillsComponent>, @Inject(MAT_DIALOG_DATA)
    public data: any, private toastr: ToastrService) {
    this.employeeSkillsForm = this.createFormGroup(data);
  }

  ngOnInit() {

    this.maxDate = new Date();
    this.employeeSkillID = this.data.employeeSkillID;
    this.selectedEmployeeID = this.data.selectedEmployeeID;
    this.employeeDetail = this.data.employeeDetail;

    console.log(this.data);

    if (this.employeeSkillID !== undefined && this.employeeSkillID !== null && this.employeeSkillID > 0) {
      this.setSkillsForm(this.employeeSkillID);
    }
  }

  setSkillsForm(employeeSkillID: number) {

    this.employeeService.getEmployeeSkills(employeeSkillID).subscribe(
      result => {
        console.log(result, 'result');
        this.employeeSkills = result;
        this.employeeSkillsForm = this.createFormGroup(result);
      },
      error => {
        console.log(error);
      });
  }

  createFormGroup(data: any) {
    return this.formBuilder.group({
      employeeSkillID: [data ? data.employeeSkillID : 0],
      skill: [data ? data.skill : ''],
      skillLevel: [data ? data.skillLevel : ''],
      description: [data ? data.description : ''],
      document: [data ? data.document : ''],
      fileSource: new FormControl('')
    });
  }

  get f() {
    return this.employeeSkillsForm.controls;
  }

  onFileChange(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      console.log(file);
      this.employeeSkillsForm.patchValue({
        fileSource: file
      });
      console.log(this.employeeSkillsForm.get('fileSource').value.name);
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    console.log(this.employeeSkillsForm);

    var fileSource = this.employeeSkillsForm.get('fileSource').value;

    if (fileSource != '') {
      const current = new Date();
      const formData = new FormData();
      var extn = fileSource.name.substr(fileSource.name.lastIndexOf('.') + 1);
      console.log(extn, 'fileName')

      var fileNameFinal = this.employeeDetail + '' + this.employeeSkillsForm.get('skill').value +
        this.employeeSkillsForm.get('skillLevel').value + '.' + extn;

      formData.append('attachmentFile', this.employeeSkillsForm.get('fileSource').value, fileNameFinal);
      console.log(fileNameFinal, 'fileName')
      console.log(this.employeeSkillsForm.get('document').value);
      console.log(formData);
      this.uploadDocuments(formData);
    }

    if (this.employeeSkillsForm.valid) {

      let employeeSkills = {
        employeeSkillID: (this.employeeSkillsForm.get('employeeSkillID').value === null) ? 0 : Number(this.employeeSkillsForm.get('employeeSkillID').value),
        employeeID: this.selectedEmployeeID,
        skill: this.employeeSkillsForm.get('skill').value,
        skillLevel: Number(this.employeeSkillsForm.get('skillLevel').value),
        description: this.employeeSkillsForm.get('description').value,
        document: fileNameFinal == null ? this.employeeSkills.document : fileNameFinal
      };
      console.log(employeeSkills);
      console.log('employeeSkills');
      if (employeeSkills.employeeSkillID !== null && employeeSkills.employeeSkillID > 0 && employeeSkills.employeeSkillID !== undefined)
        this.updateSkills(employeeSkills);
      else
        this.insertSkills(employeeSkills);
    }
    else {
      console.log('Please send valid data', this.employeeSkillsForm.value);
    }
  }

  insertSkills(employeeSkills) {
    console.log('this.employeeSkillsForm');
    return this.employeeService.addEmployeeSkills(employeeSkills).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {
        this.toastr.success('Added Successfully!');
        this.dialogRef.close('success');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }

  updateSkills(employeeSkills) {
    return this.employeeService.updateEmployeeSkillsAsync(employeeSkills).subscribe(
      result => {
        
        this.response = result;

        if (this.response.succeeded === true) {
          this.toastr.success('Updated Successfully!');
          this.dialogRef.close('success');
        }
        else
          if (this.response.failed === true) {
            this.toastr.error(this.response.message);
          }
      },
      error => {
        console.log(error);
      }
    );
  }

  uploadDocuments(formData): void {
    this.utilityService.uploadDocuments(formData).subscribe(result => {
      this.response = result;
      
    });
  }
}
