import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { EmployeeSkillsModel, EmployeeModel } from '../../../../models/employee.model';
import { EmployeeService } from '../../../../services/employee.service';
import { AddEmployeeSkillsComponent } from './add-employee-skills/add-employee-skills.component';

@Component({
  selector: 'app-employee-skills',
  templateUrl: './employee-skills.component.html',
  styleUrls: ['./employee-skills.component.scss']
})
export class EmployeeSkillsComponent implements OnInit {
  ELEMENT_DATA: EmployeeSkillsModel[];
  elements: any = [];
  displayedColumns: string[] = ['skill', 'skillLevelName', 'description', 'document', 'action'];
  @Input() regForm: FormGroup;
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @Input() userRoleName: string;
  @Input() employee: EmployeeModel;

  constructor(private employeeService: EmployeeService,
    private toastr: ToastrService,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.getEmployeeSkillsByEmployeeID();
  }

  getEmployeeSkillsByEmployeeID() {
    this.employeeService.getEmployeeSkillsByEmployeeID(this.employee.employeeID).subscribe(
      res => {
        console.log('getEmployeeSkillsByEmployeeID');
        
        this.ELEMENT_DATA = <any>res;
        this.ELEMENT_DATA.forEach((item) => {
          item.document = item.document !== null ? "assets/documents/" + item.document : null;
        }); 
        this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error => {
        console.log(error);
      }
    )
  }

  onCreate(): void {
    const dialogRef = this.dialog.open(AddEmployeeSkillsComponent, {
      width: '40%',
      data: { formTitle: 'Add New Skills', buttonName: 'Submit', selectedEmployeeID: this.employee.employeeID, employeeDetail: this.employee.employeeCode + this.employee.fullName }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  onEdit(employeeSkillID: number) {
    const dialogRef = this.dialog.open(AddEmployeeSkillsComponent, {
      width: '40%',
      data: { formTitle: 'Update Skills', buttonName: 'Update', employeeSkillID: employeeSkillID, selectedEmployeeID: this.employee.employeeID, employeeDetail: this.employee.employeeCode + this.employee.fullName }
    });

    dialogRef.afterClosed().subscribe(result => {
      ;
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  onDelete(employeeSkillID: number) {
    let result = confirm('Are you want to remove this?');
    if (result) {
      this.employeeService.deleteEmployeeSkills(employeeSkillID).subscribe(
        res => {
          this.toastr.warning('Deleted Successfully');
          this.ngOnInit();
        },
        error => {
          console.log(error);
        });
    }
  }
}
