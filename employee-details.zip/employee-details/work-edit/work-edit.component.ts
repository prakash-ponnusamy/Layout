import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormControl, AbstractControl, ValidatorFn } from '@angular/forms';
import { CompanyService } from '../../../../services/masters/company.service';
import { BranchService } from '../../../../services/masters/branch.service';
import { DepartmentService } from '../../../../services/masters/department.service';
import { SubDepartmentService } from '../../../../services/masters/sub-department.service';
import { DesignationService } from '../../../../services/masters/designation.service';
import { EmploymentTypeService } from '../../../../services/masters/employment-type.service';
import { RoleService } from '../../../../services/masters/role.service';
import { Observable } from 'rxjs';
import { CompanyModel } from '../../../../models/company.model';
import { DesignationModel } from '../../../../models/designation.model';
import { MAT_DATE_FORMATS } from '@angular/material/core';
import { startWith, map } from 'rxjs/operators';
import { ShiftService } from '../../../../services/masters/shift.service';
import { GlobalConstants, MY_DATE_FORMATS } from '../../../common/global-constants';
import { EmployeeModel } from '../../../../models/employee.model';
import { EmployeeService } from '../../../../services/employee.service';
import { ToastrService } from 'ngx-toastr';
import { AppAuthService } from '../../../../services/auth.service';

@Component({
  selector: 'app-work-edit',
  templateUrl: './work-edit.component.html',
  styleUrls: ['./work-edit.component.scss'],
  providers: [{ provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS }]
})

export class WorkEditComponent implements OnInit {
  companyList: CompanyModel;
  selectedCompany: any;
  branchList: any;
  departmentList: any;
  subDepartmentList: any;
  designationList: any;
  employmentTypeList: any;
  shiftList: any;
  roleList: any;
  maxDate: Date;
  minDate: Date;
  formSubmitted: boolean = false;
  selectedBranch: string;
  selectedDepartment: string;
  selectedSubDepartmentID: string;
  selectedEmploymentTypeID: string;
  selectedStatus: string;
  selectedRoleID: string;

  designationCtrl = new FormControl();
  filteredDesignations: Observable<DesignationModel[]>;
  response: any;
  employeeList: any;

  @Input() userRoleName: string;
  @Input() regForm: FormGroup;
  @Input() employee: EmployeeModel;
  @Output() refreshEmployeeInfo = new EventEmitter();

  constructor(private readonly companyService: CompanyService,
    private readonly branchService: BranchService,
    private readonly departmentService: DepartmentService,
    private readonly subDepartmentService: SubDepartmentService,
    private readonly designationService: DesignationService,
    private readonly employementTypeService: EmploymentTypeService,
    private readonly roleService: RoleService,
    private readonly shiftService: ShiftService,
    private readonly employeeService: EmployeeService,
    private readonly authService: AppAuthService,
    private readonly toastr: ToastrService) {
    this.maxDate = new Date();
  }

  ngOnInit() {

    console.log(this.employee, '');
    this.getCompanies();
    this.onCompanySelection(String(this.employee.companyID));
    this.onBranchSelection(String(this.employee.branchID));
    this.onDepartmentSelection(String(this.employee.departmentID));
    this.selectedBranch = String(this.employee.branchID);

    this.getDesignations();
    this.getEmploymentTypes();
    this.getRoles();
    this.getShiftList();
    this.getAllManagers();

    this.regForm.get('workDetails').patchValue({
      companyID: this.employee.companyID,
      branchID: this.employee.branchID,
      departmentID: this.employee.departmentID,
      subDepartmentID: this.employee.subDepartmentID,
      employmentTypeID: this.employee.employmentTypeID,
      employeeStatusID: this.employee.statusID,
      doj: this.employee.doj,
      doc: this.employee.doc,
      roleID: this.employee.roleID,
      reportingManagerID: this.employee.managerID,
      isManager: this.employee.isManager,
      skipManagerApproval: this.employee.skipManagerApproval,
      resignedDate: this.employee.resignedDate,
      lastWorkingDate: this.employee.lastWorkingDate,
      resignationReason: this.employee.resignationReason
    });
  }

  private _filterDesignations(value: string): DesignationModel[] {
    const filterValue = value.toLowerCase();
    return this.designationList.filter(designation => designation.designationName.toLowerCase().includes(filterValue))
  }

  getAllManagers() {

    this.employeeService.getAllManagers().subscribe(
      res => {
        
        this.employeeList = res;
      },
      error => {
        console.log(error);
      });
  }

  onCompanySelection(selectedCompany: string) {
    this.regForm.get('workDetails').get('branchID').patchValue(null);
    this.regForm.get('workDetails').get('departmentID').patchValue(null);
    this.regForm.get('workDetails').get('subDepartmentID').patchValue(null);
    
    this.branchList = null;
    this.departmentList = null;
    this.subDepartmentList = null;
    this.getBranches(Number(selectedCompany));
  }

  onBranchSelection(selectedBranch: string) {
    this.regForm.get('workDetails').get('departmentID').patchValue(null);
    this.regForm.get('workDetails').get('subDepartmentID').patchValue(null);
    
    this.departmentList = null;
    this.subDepartmentList = null;
    this.getDepartments(Number(selectedBranch));
  }

  onDepartmentSelection(selectedDepartment: string) {
    this.regForm.get('workDetails').get('subDepartmentID').patchValue(null);
    
    this.subDepartmentList = null;
    this.getSubDepartments(Number(selectedDepartment));
  }

  onDesignationSelection(selectedDesignation: string) {
    
    this.regForm.get('workDetails').get('designationID').patchValue(selectedDesignation);
  }


  getCompanies() {
    this.companyService.getCompanyByStatus(true).subscribe(
      res => {
        this.companyList = <any>res;
      },
      error => {
        console.log(error);
      }
    );
  }

  getBranches(selectedCompany: number) {
    
    if (selectedCompany > 0) {
      this.branchService.getBranchByStatus(selectedCompany, true).subscribe(
        res => {
          this.branchList = <any>res;
          
        },
        error => {
          console.log(error);
        }
      );
    }
  }


  getDepartments(selectedBranch: number) {
    
    if (selectedBranch > 0) {
      this.departmentService.getActiveDepartmentList(selectedBranch).subscribe(
        res => {
          this.departmentList = <any>res;
          
        },
        error => {
          console.log(error);
        }
      );
    }
  }

  getSubDepartments(selectedDepartment: number) {
    
    if (selectedDepartment > 0) {
      this.subDepartmentService.getActiveSubDepartmentList(selectedDepartment).subscribe(
        res => {
          this.subDepartmentList = <any>res;
          
        },
        error => {
          console.log(error);
        }
      );
    }
  }

  getDesignations() {
    this.designationService.list().subscribe(
      res => {
        this.designationList = <any>res;
        
        this.filteredDesignations = this.designationCtrl.valueChanges
          .pipe(
            startWith(''),
            map(designation => designation ? this._filterDesignations(designation) : this.designationList.slice())


          );
      },
      error => {
        console.log(error);
      }
    );
  }

  getEmploymentTypes() {
    this.employementTypeService.getActiveEmploymentType().subscribe(
      res => {
        this.employmentTypeList = <any>res;
        

      },
      error => {
        console.log(error);
      }
    );
  }

  getRoles() {
    this.roleService.list().subscribe(
      res => {
        this.roleList = <any>res;
        
      },
      error => {
        console.log(error);
      }
    );
  }
  getShiftList() {
    this.shiftService.getShiftByStatus(true).subscribe(
      res => {
        this.shiftList = <any>res;
        
      },
      error => {
        console.log(error);
      }
    );
  }

  public displayDesignationFn(designation?: DesignationModel): string | undefined {
    return designation ? designation.designationName : undefined
  }
  //step3Submitted() {
  //  console.log(this.regForm.get('workDetails').get('companyID'));
  //  //this.regForm.get('contactDetails').get('email').updateValueAndValidity();
  //}

  onEdit() {
    this.formSubmitted = true;
  }

  basicInfoCancel() {
    this.formSubmitted = false;
  }

  employmentInfoSubmit() {
    console.log(this.regForm.get('workDetails'));
    let workInfo = {
      employeeId: this.employee.employeeID,
      companyID: Number(this.regForm.get('workDetails').get('companyID').value),
      branchID: Number(this.regForm.get('workDetails').get('branchID').value),
      departmentID: Number(this.regForm.get('workDetails').get('departmentID').value),
      subDepartmentID: Number(this.regForm.get('workDetails').get('subDepartmentID').value),
      managerID: Number(this.regForm.get('workDetails').get('reportingManagerID').value),
      skipManagerApproval: Number(this.regForm.get('workDetails').get('skipManagerApproval').value),
      isManager: Number(this.regForm.get('workDetails').get('isManager').value),
      employmentTypeID: Number(this.regForm.get('workDetails').get('employmentTypeID').value),
      statusID: Number(this.regForm.get('workDetails').get('employeeStatusID').value),
      doj: this.regForm.get('workDetails').get('doj').value,
      doc: this.regForm.get('workDetails').get('doc').value,
      resignedDate: this.regForm.get('workDetails').get('resignedDate').value,
      lastWorkingDate: this.regForm.get('workDetails').get('lastWorkingDate').value,
      resignationReason: this.regForm.get('workDetails').get('resignationReason').value
    }
    console.log('workInfo');
    console.log(workInfo);
    this.updateEmployee(workInfo);

    this.formSubmitted = false;
  }

  updateEmployee(workInfo) {
    let auth = {
      id: this.employee.authID,
      roleID: Number(this.regForm.get('workDetails').get('roleID').value)
    };

    this.updateRoleByAuthID(auth);

    return this.employeeService.updateWorkInformation(workInfo).subscribe(result => {
      this.response = result;

      if (this.response.succeeded === true) {
        this.toastr.success('Updated Successfully!');
        this.refreshEmployeeInfo.emit('call parent');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );

  }

  updateRoleByAuthID(auth) {
    return this.authService.updateRoleByAuthID(auth).subscribe(
      result => {
        this.response = result;
      },
      error => {
        console.log(error);
      }
    );
  }

}
