import { Component, ViewChild, Input, OnInit } from '@angular/core';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ToastrService } from 'ngx-toastr';
import { AddEmployeeDesignationComponent } from './add-employee-designation/add-employee-designation.component';
import { EmployeeDesignationModel, EmployeeModel } from '../../../../models/employee.model';
import { EmployeeService } from '../../../../services/employee.service';
import { FormGroup } from '@angular/forms';


@Component({
  selector: 'app-employee-designation',
  templateUrl: './employee-designation.component.html',
  styleUrls: ['./employee-designation.component.scss']
})
export class EmployeeDesignationComponent implements OnInit {

  ELEMENT_DATA: EmployeeDesignationModel[];
  elements: any = [];
  displayedColumns: string[] = ['designationName', 'startDate', 'endDate'];
  @Input() regForm: FormGroup;
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @Input() userRoleName: string;
  @Input() employee: EmployeeModel;

  constructor(private employeeService: EmployeeService,
    private toastr: ToastrService,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.getEmployeeDesignationByEmployeeID();
      }



  getEmployeeDesignationByEmployeeID() {
    this.employeeService.getEmployeeDesignationByEmployeeID(this.employee.employeeID).subscribe(
      res => {
        console.log('getEmployeeDesignationByEmployeeID');
        
        this.ELEMENT_DATA = <any>res;
        this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error => {
        console.log(error);
      }
    )
  }
  currentDesignationDetails() {
    return this.ELEMENT_DATA.filter(x => x.endDate.toString() === "9999-12-31T23:59:59")
  }


  onCreate(): void {
    console.log('sdf');
    var activeDesignation = this.currentDesignationDetails();
    console.log(new Date());
    const dialogRef = this.dialog.open(AddEmployeeDesignationComponent, {
      width: '40%',
      data: { formTitle: 'Add New Designation', buttonName: 'Submit', employeeID: this.employee.employeeID, currentDesignation: activeDesignation}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  //onEdit(empDesignationID: number) {
  //  const dialogRef = this.dialog.open(AddEmployeeDesignationComponent, {
  //    width: '40%',
  //    data: { formTitle: 'Update Designation', buttonName: 'Update', empDesignationID: empDesignationID }
  //  });

  //  dialogRef.afterClosed().subscribe(result => {
  //    ;
  //    if (result !== undefined)
  //      this.ngOnInit();
  //  });
  //}

  //onDelete(empDesignationID: number) {
  //  let result = confirm('Are you want to remove this?');
  //  if (result) {
  //    this.employeeService.deleteEmployeeDesignation(empDesignationID).subscribe(
  //      res => {
  //        this.toastr.warning('Deleted Successfully');
  //        this.ngOnInit();
  //      },
  //      error => {
  //        console.log(error);
  //      });
  //  }
  //}

}
