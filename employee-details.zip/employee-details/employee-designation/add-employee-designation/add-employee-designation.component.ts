import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EmployeeService } from '../../../../../services/employee.service';
import { DesignationService } from '../../../../../services/masters/designation.service';
import { DesignationModel } from '../../../../../models/designation.model';
import { ToastrService } from 'ngx-toastr';
import { EmployeeDesignationModel } from '../../../../../models/employee.model';

@Component({
  selector: 'add-employee-designation',
  templateUrl: './add-employee-designation.component.html',
  styleUrls: ['./add-employee-designation.component.scss']
})
export class AddEmployeeDesignationComponent implements OnInit {

  employeeDesignationForm: FormGroup;
  employeeDesignation: EmployeeDesignationModel;
  employeeDesignationID: number;
  maxDate: Date;
  response: any;
  designationList: DesignationModel;

  constructor(
    private readonly formBuilder: FormBuilder,
    public employeeService: EmployeeService,
    private readonly designationService: DesignationService,
    public dialogRef: MatDialogRef<AddEmployeeDesignationComponent>, @Inject(MAT_DIALOG_DATA)
    public data: any, private toastr: ToastrService) {
    this.employeeDesignationForm = this.createFormGroup();
  }

  ngOnInit() {
    this.getDesignationByStatus();
    this.maxDate = new Date();
    console.log('employeeDesignation ngOnInit');
    console.log(this.data.currentDesignation[0].empDesignationID);


  }

  getDesignationByStatus() {
    this.designationService.list().subscribe(
      res => {
        this.designationList = <any>res;
        console.log(this.designationList);
      },
      error => {
        console.log(error);
      }
    );
  }

  createFormGroup() {
    return this.formBuilder.group({
      empDesignationID: [0],
      designationID: [0],
      startDate: ''
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    

    if (this.employeeDesignationForm.valid) {
      
      console.log(this.employeeDesignationForm.get('startDate'));
     
      let employeeDesignation = {
        empDesignationID: this.data.currentDesignation[0].empDesignationID,
        endDate: this.employeeDesignationForm.get('startDate').value,
      };
      console.log(employeeDesignation);
      this.updateDesignation(employeeDesignation);
    }
    else {
      console.log('Please send valid data', this.employeeDesignationForm.value);
    }
  }

  insertDesignation(employeeDesignation) {
    console.log('this.employeeDesignationForm');
    console.log(this.data.empDesignationID);
    return this.employeeService.addEmployeeDesignation(employeeDesignation).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {
        this.toastr.success('Added Successfully!');
        this.dialogRef.close('success');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }

  updateDesignation(employeeDesignation) {
    console.log('this.employeeDesignationForm');
    return this.employeeService.updateEmployeeDesignationAsync(employeeDesignation).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {

        let employeeDesignation = {
          empDesignationID: 0,
          employeeID: this.data.employeeID,
          designationID: Number(this.employeeDesignationForm.get('designationID').value),
          startDate: this.employeeDesignationForm.get('startDate').value,
          
        };
        console.log(employeeDesignation);
        this.insertDesignation(employeeDesignation);
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }

}
