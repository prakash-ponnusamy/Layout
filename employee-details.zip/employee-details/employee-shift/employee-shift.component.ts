import { Component, ViewChild, Input, OnInit } from '@angular/core';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ToastrService } from 'ngx-toastr';
import { AddEmployeeShiftComponent } from './add-employee-shift/add-employee-shift.component';
import { EmployeeShiftModel, EmployeeModel } from '../../../../models/employee.model';
import { EmployeeService } from '../../../../services/employee.service';
import { FormGroup } from '@angular/forms';


@Component({
  selector: 'app-employee-shift',
  templateUrl: './employee-shift.component.html',
  styleUrls: ['./employee-shift.component.scss']
})
export class EmployeeShiftComponent implements OnInit {

  ELEMENT_DATA: EmployeeShiftModel[];
  elements: any = [];
  displayedColumns: string[] = ['shiftName', 'startDate', 'endDate'];
  @Input() regForm: FormGroup;
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @Input() userRoleName: string;
  @Input() employee: EmployeeModel;

  constructor(private employeeService: EmployeeService,
    private toastr: ToastrService,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.getEmployeeShiftByEmployeeID();
      }



  getEmployeeShiftByEmployeeID() {
    this.employeeService.getEmployeeShiftByEmployeeID(this.employee.employeeID).subscribe(
      res => {
        console.log('getEmployeeShiftByEmployeeID');
        
        this.ELEMENT_DATA = <any>res;
        this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error => {
        console.log(error);
      }
    )
  }
  currentShiftDetails() {
    return this.ELEMENT_DATA.filter(x => x.endDate.toString() === "9999-12-31T23:59:59")
  }


  onCreate(): void {
    console.log('sdf');
    var activeShift = this.currentShiftDetails();
    console.log(new Date());
    const dialogRef = this.dialog.open(AddEmployeeShiftComponent, {
      width: '40%',
      data: { formTitle: 'Add New Shift', buttonName: 'Submit', employeeID: this.employee.employeeID, currentShift: activeShift}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined)
        this.ngOnInit();
    });
  }

  //onEdit(empShiftID: number) {
  //  const dialogRef = this.dialog.open(AddEmployeeShiftComponent, {
  //    width: '40%',
  //    data: { formTitle: 'Update Shift', buttonName: 'Update', empShiftID: empShiftID }
  //  });

  //  dialogRef.afterClosed().subscribe(result => {
  //    ;
  //    if (result !== undefined)
  //      this.ngOnInit();
  //  });
  //}

  //onDelete(empShiftID: number) {
  //  let result = confirm('Are you want to remove this?');
  //  if (result) {
  //    this.employeeService.deleteEmployeeShift(empShiftID).subscribe(
  //      res => {
  //        this.toastr.warning('Deleted Successfully');
  //        this.ngOnInit();
  //      },
  //      error => {
  //        console.log(error);
  //      });
  //  }
  //}

}
