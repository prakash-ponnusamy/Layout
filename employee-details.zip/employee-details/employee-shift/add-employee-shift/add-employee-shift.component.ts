import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EmployeeService } from '../../../../../services/employee.service';
import { ShiftService } from '../../../../../services/masters/shift.service';
import { ShiftModel } from '../../../../../models/shift.model';
import { ToastrService } from 'ngx-toastr';
import { EmployeeShiftModel } from '../../../../../models/employee.model';

@Component({
  selector: 'add-employee-shift',
  templateUrl: './add-employee-shift.component.html',
  styleUrls: ['./add-employee-shift.component.scss']
})
export class AddEmployeeShiftComponent implements OnInit {

  employeeShiftForm: FormGroup;
  employeeShift: EmployeeShiftModel;
  employeeShiftID: number;
  maxDate: Date;
  response: any;
  shiftList: ShiftModel;

  constructor(
    private readonly formBuilder: FormBuilder,
    public employeeService: EmployeeService,
    private readonly shiftService: ShiftService,
    public dialogRef: MatDialogRef<AddEmployeeShiftComponent>, @Inject(MAT_DIALOG_DATA)
    public data: any, private toastr: ToastrService) {
    this.employeeShiftForm = this.createFormGroup(data);
  }

  ngOnInit() {
    this.getShiftByStatus();
    this.maxDate = new Date();
    console.log('employeeShift ngOnInit');
    console.log(this.data);


  }

  getShiftByStatus() {
    this.shiftService.list().subscribe(
      res => {
        this.shiftList = <any>res;
        console.log(this.shiftList);
      },
      error => {
        console.log(error);
      }
    );
  }

  createFormGroup(data: any) {
    return this.formBuilder.group({
      employeeShiftID: [0],
      shiftID: [0],
      startDate:[0],
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    console.log(this.employeeShiftForm);
    console.log(this.data.currentShift);
    console.log('countcheck ');
    if (this.employeeShiftForm.valid) {
      if (this.data.currentShift.length > 0)

        //if (this.data.currentShift[0].employeeShiftID > 0)
        this.updateShift();
      else
        this.insertShift();
    }
    else {
      console.log('Please send valid data', this.employeeShiftForm.value);
    }
  }

  insertShift() {
    console.log('this.employeeShiftForm');
    console.log(this.data.employeeShiftID);

    let employeeShift: any = {
      employeeShiftID: 0,
      employeeID: this.data.employeeID,
      ShiftID: Number(this.employeeShiftForm.get('shiftID').value),
      startDate: this.employeeShiftForm.get('startDate').value
    };

    return this.employeeService.addEmployeeShift(employeeShift).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {
        this.toastr.success('Added Successfully!');
        this.dialogRef.close('success');
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }

  updateShift() {
    let employeeShift:any = {
      employeeShiftID: this.data.currentShift[0].employeeShiftID,
      endDate: this.employeeShiftForm.get('startDate').value
    };
    console.log('this.employeeShiftForm');
    return this.employeeService.updateEmployeeShiftAsync(employeeShift).subscribe(result => {
      this.response = result;
      if (this.response.succeeded === true) {
        this.insertShift();
      }
      else
        if (this.response.failed === true) {
          this.toastr.error(this.response.message);
        }
    },
      error => {
        console.log(error);
      }
    );
  }

}
